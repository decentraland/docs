# The Review Lens — Used Openly

Your working copy of the programme's `reviewer-checklist.md`: it lets you see the document as a
reviewer will, early enough to act. **Never an authority you hold over a creator** — the programme
decides submissions, and an unproven promise is what a proposal *is*.

- **No totals, no thresholds, no predicted verdict.** Report what is weak and what would lift it.
- Before calling something a contradiction, verify both premises against the owner's decisions or
  original evidence. An unspecified behaviour is an open question; your inferred rule cannot prove
  a design defect. Check the relevant saved section before saying a fact or experience is missing;
  an empty later section does not erase an answer elsewhere. Keep uncertain deductions conditional.
  Reconcile findings shared by several checks: one consequence for the same
  unresolved issue. Choosing to leave it open does not remove its application risk. A design
  weakness is not an official eligibility rule; name which kind of gap the evidence supports.
  A paper pressure-test pass establishes coherence, not observed player enjoyment.
- **A hit is a move, not a rejection** — a clarification, a targeted revision, or the one thing worth
  deciding before more writing happens.
- "P4", "preflight", "status" are your words, never the owner's (hard rule 7) — to them it is *"Why
  Players Come Back is the thin one"*.

Load for phase 3's audit, or a full review on entry. Phase 0 ordinarily needs only
[preflight.md](preflight.md). The probe questions can also guide targeted revisions.

---

## Preflight — P1–P9

The entry checks live in [preflight.md](preflight.md); repeat all nine during the audit.

---

## Review areas — the acceptance lens

One status per area, never averaged, never totalled. This is the merged checklist's decision record,
used on yourself before a reviewer uses it on the document.

- **Clear** — specific, internally consistent, scoped, and supported by suitable evidence or a
  credible test plan.
- **Follow-up** — plausible, but an important operation, assumption or proof is missing.
- **Blocker** — a material gap or contradiction in the proposed design, or conflict with a fixed
  requirement. This area label is not a ban on submitting an incomplete document. Distinguish
  a design concern from a verified programme condition; explain the consequence, not a rejection.
- **Not applicable yet** — the evidence belongs to a later stage. Live retention data at concept
  stage is this, never "insufficient".

| Review area | Where it lives | Clear looks like |
|---|---|---|
| Player promise & Decentraland fit | §0, §1, §8 | ≤25 words, a role, a verb, a goal and exactly one strange thing; repeatable from memory. The promised action has a credible input/control/feedback path on the target client, or an explicit feasibility test ([platform fit](platform-fit.md)). |
| Immediate comprehension | §2 | The spawn frame communicates the verb; first useful action inside 5 s, the goal stateable by 10; first reward inside a minute. |
| Core gameplay & repeatability | §3 | 3–5 verbs, a 30–90 s cycle, and a concrete reason repetition 10 remains appealing, through variation or a repeatable pleasure. |
| Progression & return design | §2, §4 | A concrete D1 reason known or anticipated before re-entry; timing when the mechanism needs it; two hooks explained *in the design*, not name-dropped; a first-week player with named persistent state. |
| Intentional social play | §5 | Worthwhile solo play is described, with uncertainty intact; other players improve it concretely. Waiting, inviting or theoretical survival is not the solo answer; play is legible to bystanders. |
| Social continuity | §5 | A player learns another player's name; one player's action changes a specific other's next session, and they learn who did it. |
| Audience & first viable crowd | §5, §8 | A primary player described through experience, not demographics; two comparables actually played, each with an honest failure. |
| Mobile readiness & world legibility | §6, §7 | Every core-loop verb mapped to touch; UI small-screen-first; the biggest performance risk named with a plan. |
| Agreed four-week V1 scope | §9 | The week plan is credible against the declared cuts; real cuts where needed, preserving the core promise; a risk and its fallback named. |
| Evidence quality & testability | §0, linked artifacts | Links open and match the stated stage; what is untested says so; the cheapest next proof is named. |

**The return area carries the most weight**, and it is the one place where the programme's own move is
explicit: *return for targeted revision when the only theory is "fun" or unspecified future content*.
That is a revision, not a decline — and unproven is not the same as missing. A hook with a real
mechanism behind it and no playtest yet is Clear with a test plan; a hook that is a word is
Follow-up.

Deliver any weak area **as the next step, never as a verdict**. The collaborative register is in
[playbook.md](playbook.md)'s Voice notes — *"that is the question doing its job, not you failing"*.

---

## Conformance count

Run in the phase-3 audit — mechanical, no judgement, straight against the template: 25 words on
the promise · 180 across the First Minutes player-experience cells, excluding fixed time labels · 3 × 8 words of How to Play · 2 sentences of story · 1
sentence for the primary player · 2 for arrival and 2 for bring-a-friend · exactly 2 return hooks
· exactly 2 comparables · real cuts when needed · at most 4 live-ops lines · at most 3 examples anywhere
· and every field the template labels with a sentence/line limit.

Count **presence** the same way: every template section and fixed block — the §9 live-ops block
included — is present, or absent by a written decision (a stage banner naming it, an honest
`TBD:`); a full-looking document with a silently missing block reads complete and fails review
on the gap. The reverse also fails: a section the template does not name is overflow — move its
content to `design/implementation-notes.md` (technical) or `design/ideas.md`, and leave the
design-facing sentence where the template has a home for it.

---

## The audit checks

The phase-3 audit runs these five checks over the whole draft; SKILL.md keeps their names, this is
the prose.

1. The template's own **submit self-check** — its criteria table is the program's assessment frame,
   so read it as the acceptance lens, not as one more checklist.
2. The **pressure tests** (below), plus the **cross-lens audit** from
   [design-lenses.md](design-lenses.md) — four lines of design theory over the whole draft. Each
   failure becomes a fix, a `TBD:` with a plan, or an explicit
   "accepted, and here is why".
3. The **P1–P9 preflight again** ([preflight.md](preflight.md)), now over the draft rather than over the input — a design
   can walk into a hit during the interview.
4. The **conformance count** — mechanical, no judgement, straight against the template: the full
   cap list, the presence check and the overflow rule are in **Conformance count** above (hard
   rule 3 on overflow).
5. An honest read of the **review areas** as the acceptance lens
   (above) — one status each, **no total and no
   predicted verdict**. Assess every area internally; the recap names material findings once,
   not every status or a new task for every gap. Separate unclear writing from untested intent;
   the latter stays open, with a hypothesis file only when its parking requirements are met.

## Pressure tests

Run these in phase 3, over the full draft. Each is a pass over the document, not a question — report
what fails, then fix it, park it as `TBD:` with a plan, or accept it out loud with a reason.

| Test | Passes when |
|---|---|
| **Verb trace** | Every verb in §3 appears in §2's first session and has a touch row in §6. A verb missing from either is a hole. |
| **Promise trace** | §2's first session shows the distinctive experience promised in §1. That may be a quiet sensation or act of expression; it need not be conflict, novelty or tension. Check the actual promise, not a different game you prefer. |
| **Repetition test** | §3 names what changes or stays enjoyable at repetition 10; “procedural” or “relaxing” alone is not an explanation. A concrete familiar pleasure is a valid hypothesis. |
| **No-push test** | Walk §4 assuming nothing will ever remind the player this experience exists: what survives is a hook, what does not is a wish. |
| **Quiet-hour test** | §5 re-run at 2 concurrent players still has an answer. Silence is a failing answer. |
| **Scope coherence** | Check the chosen playable outcome, dependencies and actual deferrals. Assess effort against capacity only when an estimate was discussed, with its assumptions. Missing hours or budget figures are not a submission defect; do not start a financial interview during audit. |
| **Cut-list test** | The cut list hurts. A painless one means nothing was decided — go back. |
| **Stranger test** | Someone who was not in this conversation could prototype the core loop from this document alone. Name every place they would have to guess. |
| **Evidence test** | §0 links to something playable — or names the cheapest thing that could exist there by next week, and it is already in the Hypothesis Log. |
| **Hypothesis audit** | Every `[HYPOTHESIS]` marker has a row in `design/hypothesis-log.md`; every row has a falsifiable IF/THEN and a cheapest killing test. A core loop still hypothetical is the next experiment, before anything else in the document gets built. |
| **Lore ratio** | World and story do not outweigh the rest of the document — otherwise it is a lore wall regardless of how good the lore is. |

---

## Probe questions — reuse them verbatim as interview questions

The full set of fourteen, with what good and bad answers sound like, is in the merged
`reviewer-checklist.md` (a citation, not a path — the file is not bundled). The ones that earn their
keep mid-interview:

1. *"What does the player repeatedly do, how long is one cycle, and why is the 10th repetition still
   fun?"* — good: one verb, 30–90 s, a concrete repeat-play appeal. Bad: a feature list or “exploring” without an action and response.
2. *"A new player spawns in. What in the first camera frame tells them what to do — without text?"* —
   good: one dominant affordance, or other players visibly mid-loop. A short hint on top of a visible
   cue is fine.
3. *"Decentraland cannot send push notifications. What will a Day-1 player *remember*, or *who* will
   call them back on Day 2?"* — good: "their plot finishes in 20 h", "Sunday reset", "crew race
   Friday". Bad: "the fun".
4. *"What is different for a Day-7 player, and walk me through their session as a scene."* — good:
   named persistent state others can see. Bad: "they have seen more levels".
5. *"How does a player who arrives alone end up interacting with someone — by design, not luck?"*
6. *"If every other player vanished but their traces stayed — what breaks?"* — "nothing", said
   openly, is honest and legitimate: a solo game with social evidence around it. It is only a problem
   when the document claims otherwise.
7. *"What does your world look like at 4 a.m. with two concurrent players?"* — this is what separates
   a social design from a social hope on a low-concurrency platform.
8. *"Name a feature you already rejected because it did not serve a pillar."*
9. *"Which two comparables did you actually play, and what did not fit your audience in each?"*

The good-answer examples are drawn from the reviewer's guidance: agreeing to one decides nothing —
see rubric cosplay in [interview-moves.md](interview-moves.md).

---

## Calibration

- **Retention numbers.** First-week return — the share of eligible new players back at least once
  in days 1–7: v1 floor **>10%**, programme target **>20%**, *insufficient evidence* below ten
  eligible users — and **never set against mobile-F2P "D7"**, which counts players active *on* day 7
  and runs mechanically lower. Definitions, comparison class and provenance:
  [retention.md](retention.md#benchmarks), the canon — read it before quoting any number beyond these.
- **Return fit:** apply [the no-reminder test](retention.md#the-no-reminder-test). Judge the
  concrete next experience and how the player anticipates it, not the presence of a timer,
  reset or genre label. Discuss a mismatch with the return goal without prescribing a system.
- **The social ladder is a spectrum, not a gate** — present → recognizable → consequential. A
  well-designed co-presence game is fundable; the top of the ladder is for designs where *these
  particular people* are part of the reason to return.
- **Churn is socially contagious** — groups amplify retention and collapse alike. Prefer small,
  re-formable groups over one large fragile community.
- **Social ties are the strongest late-retention force in the literature.** A document that nails
  social design earns benefit of the doubt elsewhere.
- **Familiar genre plus one twist beats novelty** for inexperienced teams. Do not penalize a
  derivative anchor; penalize a missing twist.
- **Text cannot prove fun.** Anything playable outranks pages of description, and the document's job
  is to answer what a prototype cannot show.
