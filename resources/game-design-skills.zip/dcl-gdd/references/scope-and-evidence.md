# Scope and Evidence

Load at Step J (§9 the 4 Week Plan) and for §0's evidence rules (Step K) — the reality-check act.
Two review areas live here (the four-week build, evidence quality) plus the v1-scope preflight (P6).
The template has no separate team, success-criteria or deliverables sections; what survives of them
is folded in below.

## Why playable evidence outranks everything written

For owner-raised funding or effort questions, apply [funding and scope](funding-and-scope.md).
Planning a playable outcome does not require a financial review.

For a claim about play, ask what someone can try or observe. A document explains the intended
experience; a playable slice lets someone examine the action and response. Neither a polished
pitch nor the existence of a build proves enjoyment. Link the strongest relevant evidence and
state what it actually supports.

| Playable evidence linked in §0 | Weight |
|---|---|
| Rough core mechanic in any engine, even a web demo | **good** |
| Playable core loop in SDK7 | **great** |
| Small vertical slice live in a World | **excellent** |

One link outweighs pages of description. With no build, ask what is the cheapest thing that could
be linked by next week — and park its test: that thing is a Hypothesis Log row.

**Match each claim to its evidence.** Record who observed what, on which build/client and under
which conditions when known. An owner report is a report, not agent-verified measurement; your own
`decisions.md` is not independent confirmation. Missing details stay unknown, never invented.
Keep observations in a short attributed evidence note beside the relevant section, or link an
existing test record. Design fields still describe the action, intended outcome or player
anticipation; do not put sample counts or test caveats into those cells. Preserve a useful small
sample as a limited report, even when it cannot support the dashboard metric or a causal claim.
Do not add an evidence column or fill prototype-owned Sessions/Verdict on the owner's behalf.
A before/after preference supports the reported improvement, not an isolated cause. If several
things changed, practice or recall may also matter; do not declare one change the proven fix.
Keep the useful observation and the causal question separate. No automatic A/B study is needed;
only suggest a focused comparison if that distinction changes the next design decision.
A past test can support a limited observation even if the build is no longer accessible. It does
not prove the current build or a different client. Offer the smallest relevant retest when needed
(silent in doc-only), not an automatic rebuild of everything previously tested.

**Check the uncertain part before multiplying content.** Offer a small test of the core assumption
when useful; estimate its work from this project rather than quoting universal budget percentages.
A prototype costs time too. In doc-only, record the test without an invitation to build.

## Optional effort estimate

When the owner wants an estimate, ask only for missing capacity and reuse assumptions. Keep the
estimate in chat unless they want it in the GDD. Do not invent hours or demand this discussion
before submission. A chosen scope cut still updates the plan and its dependent promises.

## §9 The 4 Week Plan

The V1 table covers the agreed four-week scope, including release work. Choose intermediate
checks to suit the experiment and capacity; suggested week labels are not fixed program gates.
For a V0 application, separate the small entry scene from the proposed funded slice; do not
require a complete V1 plan as V0 delivery. Confirm V0 timing instead of applying four weeks to it.

For a requested estimate, compare content quantity × per-unit effort with the available time.
State assumptions and uncertainty; offer a smaller scope rather than forcing a commitment.

**At most three examples** wherever content is listed: levels, minigames, items, biomes. Three shows
variety; ten shows unscoped ambition, and reviewers read it exactly that way. A cap on examples and a
scope smell detector, never a quota to design three of anything.

**Cut only where scope needs it.** Identify the actual work deferred or removed; preserve the
core promise, or explicitly revisit it with the owner. No minimum count or painful sacrifice is
required. A cut removes previously chosen work: do not invent a larger past scope to populate
this list. An unchosen suggestion is an option, not a cut. Separate the reusable system from its
content volume when estimating savings; fewer levels may not remove the system's build cost.
Record real deferrals in `ideas.md`; a possible later return is not a funded commitment.
Apply the growing-document dependency rule: a deferred feature must not remain a current promise
in progression, social play, the plan or the rendered pitch.

**Standing non-goals are optional:** a non-goal earns its line only once it has refused a concrete
idea, mechanic or comparable. "Never a rage game, so death never rolls back progress" does; "never
boring" does not. Current truth in the template, history in `decisions.md`.

**One top risk and its fallback** — technical, design or performance. Ask which uncertainty most
threatens the proposed experience and what could still ship if it fails. An explicit fallback
helps a reviewer understand the plan; it does not guarantee their confidence or approval.

**Live ops — maximum four lines**, in the template's shape: what rotates without a new level and how
often; what still varies if an update is skipped; what persists across resets and how fast a new or
returning player becomes meaningful again; one player behaviour that changes what gets built next.
`N/A` is legal when nothing resets and there is no power gap. Fit support to the studio's chosen
post-launch capacity, separately from build capacity. Discuss the work behind a proposed cadence; quantify hosting, moderation, fixes and content
only when an effort estimate is wanted. Reusable systems or evergreen variation
may need no scheduled content release. A weekly event, reset or staffing allowance is not a default.
If the estimate exceeds capacity, simplify the promise with the owner; do not assign extra hours.

## Success criteria are the programme's, not the owner's

Use the template's submit self-check and the programme's *What Makes a Great Experience* criteria:
5/10, voluntary continuation, the return targets and the Discoverability Bar. Return definitions,
numbers and sample limits live in one place — [Retention — Benchmarks](retention.md#benchmarks);
quote from there, never from memory.

The dashboard already measures return: do not plan around custom in-game tracking, and do not let a
GDD invent a measurement framework. What the owner owns is the design response: weak first
minutes → §2, missing return hooks → §4, missing long-term social ties → §5.

## IP and content declaration — now a header self-check

Check the current public game/experience title, scene name, World name (including its public
identifier), studio branding, and used characters, logos, music, art, models and other assets.
A named inspiration is not by itself copied content; distinguish comparison from actual use.
Raise a concrete concern when it appears, without declaring an uncertain case a proven violation.

Before submission preparation ends, if no current confirmation exists, ask one short question:
"Have you checked the game, scene and World names and the materials you use for IP and Content
Policy issues — anything needing permission or still uncertain?" Reuse an explicit earlier answer;
do not repeat for formatting edits. An owner may leave the check TBD without another question loop.

Keep **owner declaration** separate from **screening performed**. Before recording a checked
name, search the exact title and close spelling/spacing variants without a category or platform
filter first, including scene and World names when different (split joined words in addresses).
Then investigate relevant matches across games, films, TV, books, brands and other works;
do not limit screening to games or Decentraland. Establish whether a result is this project,
a mirror, or another work before calling it a collision; unknown ownership stays unknown.
Open relevant primary pages with a page-reading tool (e.g. WebFetch; discover it if not loaded).
A WebSearch answer is not an opened page, even when it quotes text or lists links. In `decisions.md`,
record the date, queries, source URLs and what each actual tool result supports: search-only,
page opened, or unavailable. Never report a page read or licence verified from a search summary.
For ordinary name screening, report a match to an existing work/brand, not a trademark verdict.
Only state a mark's registration, current status or legal owner after reading the official registry
record; otherwise leave these unverified. A studio page can establish a film-title match without
proving trademark status. If browsing is unavailable or
the search was not done, say `not searched`; model familiarity is not a search. This is preliminary
name screening, not a trademark/legal clearance. A collision is a concern to investigate, not
proof of infringement; no hits do not prove rights. Asset ownership does not check a title.

Save a short, scoped status in the **Public experience title** cell, restoring it if absent:
`IP & Content Policy: owner declaration: <reported scope or TBD>; name screening: <not searched /
concern found / no obvious match in sources checked, date>; unresolved: <specific gaps or none
reported>`. Use these scoped findings, not `clear`, `passed`, `safe` or `IP Check Passed`, even
with a web-only disclaimer. An inherited
pass without evidence becomes unverified, not evidence you can reuse. Attribute the owner's
claims without expanding them: 'I checked' does not say what was checked or what was found;
leave missing scope/results unknown. A promise to use original/licensed material is not proof
about present content.
**Permission documented** needs a source/document reference and the use it covers; otherwise
keep the claim attributed with documentation TBD. Never infer rights from silence, lack of hits
or World registration. Keep known concerns visible after a blanket yes; offer a rename,
replacement or rights check without blocking unrelated work or inventing submission conditions.

A renamed game does not clear the new name or an unchanged scene/World identifier. Reopen only
the affected scope; unchanged assets do not need rechecking just for a rename. Record any external
name concern against the old public identifier too, even when the owner owns that World. If a
rename is the chosen remedy, require it to cover the affected public identifiers, not just the
display title; otherwise keep that part unresolved. A different World address requires another
NAME and deployment there, not a title edit. Explain this before planning the change; never buy
or migrate without the owner's approval. Check current NAME cost/availability when needed.
Preserve earlier findings as history, and replace contradictory current statuses throughout the edited GDD,
including its title and summaries; adding a correct field beside an old pass is not a correction.
Before the final summary, read the saved current statuses, including repeated fields; resolve stale
contradictions using the latest evidence or owner statement. Keep the chat summary within those
same scopes. Do not merge projects, revive a resolved question, broaden a limited search into
"no matches anywhere", or call a recorded concern harmless without evidence.
The submit checkbox records the declaration
and screening status (including honest TBD), not guaranteed rights or approval. Do not tick it
without that basis; an owner may submit with the uncertainty visible.

## Probes

- "What can I click right now?"
- "Who outside your family has played it, and what did they do wrong?" Owner self-test still
  can guide an early experiment; it does not replace agreed V0 playtesting.
- "Show one week of your after-launch calendar and its cost in person-days."
- "Which deferred work saves the most effort while preserving the core?"

## Smells

- Polished document, no playable link (the effort went into the document, not the game).
- Invented traction — "everyone we showed it to loved it", with no names and no numbers.
- Scope exceeding chosen capacity without a response; a risk block silent about the main concern.
- Weekly-content promises from a one-or-two-person team.

## Park

Scope hypotheses are cheap to test and almost never tested. Park them anyway:

- "This content takes N hours to build" — build one unit and measure; the most useful thing a team
  learns in week 1.
- Economy, progression and timer pacing — paper arithmetic, no build needed; never let them survive
  untested to a costlier rung.
