# Retention — The Section Graded Double

Loaded at Step F (§4), before the first question, so it already carries a benchmark and a pattern.
Order inside §4: **two hooks (4.3) → next-day sentence (4.1) → progression chain (4.2)**.
The [playbook's standing rules](playbook.md) apply to platform facts and source citations.

## The no-reminder test

Do not make return depend on reminders. For each hook, ask what the player already knows,
remembers or expects **before opening the scene again**. Events and Community channels can
remind them; the table still needs a plausible reason when that reminder is absent.
Information discovered only after re-entry can reward returning, but cannot by itself explain
that entry. A prior visit may create anticipation; a single last-seen timestamp does not
establish another player's schedule. Keep the claimed link a hypothesis until tested.

First-session enjoyment, next-visit anticipation and long-term involvement are questions,
not mandatory systems. A timer or appointment is one option; an unfinished discovery, a new
approach to a challenge or a wanted rematch may fit better. Name the concrete next experience,
not just "because it is fun". No daily reset, streak or fixed hour is required by this frame.
Reuse the recorded choice or refusal; do not offer a rejected mechanism again under a new name.
Revisit it only at the owner's request or when a changed premise makes it relevant, saying what
changed. An untested chosen hook can remain a hypothesis without another menu of alternatives.

| Symptom | Question to investigate | Where |
|---|---|---|
| Players do not finish session one | Is the action clear and enjoyable? | §2 first minutes, §3 loop |
| They enjoy it and never return | What do they expect from another visit, and how do they know? | §4.3 hooks |
| They return for a fortnight, then drift | Does play still offer meaningful goals, variation or connection? | §5 social, §4.2 week-3+ goal |

## Benchmarks

**The single canon for retention numbers in this skill** (traced 2026-08-28). Read this block before
quoting or comparing a retention figure anywhere; review-lens Calibration and scope-and-evidence
carry pointers here, nothing more.

- **Program dashboard D7 = first-week return:** the share of new players who come back *at least
  once during days 1–7* (the template's glossary). **v1 floor >10%; program target >20%.** Both bars
  apply only once the view holds **at least ten eligible new users with a completed window**; below
  that the verdict is *insufficient evidence*, not a fail.
- **Never set against mobile-F2P "D7"**, which counts players active *on day 7* and runs
  mechanically lower: "our 20% against an industry median of 4–8%" compares two different metrics
  and overstates the bar.
- **UGC platforms are the comparison class:** D1 >30% / D7 >15% is where paid discovery starts to
  make sense, and D7 ≥15% predicts CCU growth (RoLearn / Roblox culture), against a devforum reality
  band of D1 2–11% for ordinary experiences. Provenance: the source repo's
  `research/metaverse-ugc-funding-research-2026-08.md` — a citation, not a bundled path.
- The mobile-F2P figures (median ~4–8%, "good" 13–16%) have **no source in this repo**: private
  orientation only, never quoted at a creator as a benchmark.
- **Genre fit is a question, not a verdict.** Ask what in this particular design could support
  return. If the intended one-shot experience conflicts with the return goal, discuss the trade-off
  with the owner; do not prescribe a meta layer or social obligation from its genre label.

Frame >20% for a creator as **ambitious by platform standards** — neither a top-decile miracle nor
a formality.

## 4.3 — two hooks, priced inside this design

**Exactly two; at least one creates a concrete next-day reason.** For each: exact trigger or timing,
what the player anticipates, reminder channel and no-reminder fallback. Timing is required only
when the mechanism depends on it; an unknown duration remains a design question. Naming a menu item earns
nothing — the reviewer reads integration; explain its mechanic in this game. The menu mirrors the
template's; own inventions are welcome.

| Hook | Why it works without push | Requires | Failure mode |
|---|---|---|---|
| Appointment timer | The player's memory is the notification: a remembered future completion, respawn or unlock | Per-player persistence; readable countdown; something wanted behind the timer | Waiting becomes the loop (P1). Shorten a future session, never fill the current one with waiting |
| Daily goals + streak | Loss aversion drives short-horizon return | Real loop variety; milestone recovery | Retention theatre: dailies bolted onto an experience nobody opens daily; arbitrary rotation; punishing reset to zero |
| Weekly leaderboard reset / small leagues | Automatic deadline and fresh rank, near-zero content cost | Comparable score; groups where mid-table players can move | One global board owned by the top ten. Small leagues, always |
| Named rival | "Marta beat your 47.2" makes a person matter | Attributable score; the beaten player learns who did it; overlap for rematches | An anonymous board wearing a rival's name |
| Collection | Visible, unfinished x/N; evergreen once shipped | Cheap, distinct items; displayable reward; a plan for completion | Grind in disguise: item 14 of 20 takes ten hours |
| Recurring scheduled event | A fixed time remembered; Event listing and Community only remind | A reusable automated template; someone reliably hosts it | A bespoke event every week from a tiny team |
| Team / crew obligation | "My crew expects me" — among the strongest retention forces known | Persistent groups, shared goals, something at stake for attendance | Contagious churn collapses one fragile community; use small, re-formable groups |
| Season track | Deadline and comeback at the next season | Free 6–8-week track after launch; enough progression; program-cycle alignment; useful latecomers | Season one is lovingly authored; season two never ships |
| Async traces | An inhabited world at quiet hours, near-zero ongoing cost | Persistence, storage, moderation, expiry; legible traces on the loop's path | Nobody notices the traces |

Match hooks to §3's measured rhythm: a 60-second loop / 20-minute session can support a weekly
league and a collection, not three daily quest chains. Prefer reusing the loop to adding a system;
cheap and automatic beats rich and manual for a small team.

## 4.1 — the next-day sentence

*"A player who enjoyed their first session returns the next day (D1) because [Hook 1 or 2]
___, which they know or anticipate from ___."*

Point to one chosen hook and a specific next experience. Include a completion time, deadline or
meeting time only if it matters to that hook. A weekly event explains its scheduled visit, not
necessarily tomorrow's visit; ensure at least one selected hook actually addresses D1.
Unfinished exploration needs a wanted discovery or approach, not an unlimited promise of more
content. Scheduled mechanisms are equally valid when chosen for this game and feasible to run.

## 4.2 — the progression chain

**Repeatable action → persistent reward → new capability, status or social role → new decision or
challenge.** A larger number alone does not count. Each row names what persists, what it opens, and
how another player can tell:

- **End of first session:** something persists, giving §2's stopping point something to show.
- **End of first week:** name the state — rank, collection at 7/20, crew, upgrade, visible cosmetic.
  "More levels seen" is a conveyor toward content exhaustion. Then narrate this session in
  **3–4 second-person sentences**; it must differ from session one.
- **Week 3+:** a goal taking more than two weeks, with progress visible to others. At what moment
  does a stranger notice? An inspect screen or invisible XP is not visible progress; a wearable,
  title or board entry also markets the experience.

For currency or tradable rewards, add one line: how earned, how spent or removed, main abuse risk.

## Park

- Each hook is its own behavioural hypothesis, ordered by cheapest killing test: timer lengths →
  paper arithmetic, sometimes before a build; collection pacing and season length → a spreadsheet,
  then a session; crew obligations actually forming → real people in a live World, the most
  expensive claim in the section and the one most often assumed.
- Neither hook closes as "obviously true"; the next-day sentence stays a hypothesis until a live
  World supplies evidence.
