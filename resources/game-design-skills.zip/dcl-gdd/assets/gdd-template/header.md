# Game Design Document (GDD) Template

**Decentraland Creator Success Program**

*Fill this in, rename the heading to your game's title, and save it in your repository as `/design/gdd.md` — that saved file is the GDD the program reviews.*

| |                                                                                                                   |
|---|-------------------------------------------------------------------------------------------------------------------|
| Public experience title | ___ — IP & [Content Policy](https://decentraland.org/content/) status: owner declaration: ___ / `TBD:`; name screening: not searched / concern found / no obvious match in checked sources (date: ___); unresolved: ___ |
| Deployment target | World NAME or Genesis City coordinates or leave it as `TBD:`            |
| Studio / team name |                                                                                                                   |
| Date |                                                                                                                   |
| Contact (Discord + email) |                                                                                                                   |

---

