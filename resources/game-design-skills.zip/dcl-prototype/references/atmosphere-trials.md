# Atmosphere — try a small lived moment

Read when mood, light or sound carries the current question. Choose one useful trial, not a full
art pass. These original prompts draw on developer accounts; their engine tools and production
budgets are not requirements. Implement through the public DCL SDK and check the target client.

## Find the image before making everything

What small place would express the owner's idea? Assemble a rough, walkable fragment from
available shapes and suitable assets. Try the composition, colour and one distinctive detail
together before deciding what needs custom work. A changed combination can establish a preferred
direction without identifying which element caused it. A striking still does not prove the
moving experience. [Efremov, Neon](https://unity.com/blog/games/neon)

## Keep the important information perceptible

When darkness or visual clutter makes an action hard to read, try reducing competing accents
or separating its silhouette from the background. Let the player approach without explaining
where to look, then ask what they noticed. Preserve deliberate uncertainty when it serves the
idea; do not equate poor visibility with fear or assume light always attracts.
[Lundeen, Left 4 Dead](https://www.l4d.com/blog/post.php?id=2129)

## Give sounds different roles

Which sound establishes the place, which identifies a location, and which invites interpretation?
Try only the roles needed now: perhaps a quiet room tone and a distant, intermittent rattle.
Listen while moving, then mute one layer if signals compete. Ask where the listener thought the
sound came from and what it meant. Positional audio, occlusion and reverberation need separate
SDK/client support; do not promise the source game's audio system.
[Capcom, The Sound of Horror](https://media.gdcvault.com/gdc2017/Presentations/Usami_Ken_The_Sound_of.pdf)

For an uncertain threat, one noise might plausibly belong to the setting or to something nearby.
Try that ambiguity before a reveal; ask about the interpretation afterwards. Confusion alone
does not establish tension, and repetition may change the interpretation.
[Napper, Alien: Isolation](https://news.xbox.com/en-us/2014/10/07/games-aliens-isolation-interview/)

Save observations in the current exploratory or experiment record. No scare score, new report or
fixed number of layers is needed. Use [scene resources](scene-resources.md) if a signal is missing.
