# Design lenses — questions, alternatives, experiments

Use before a difficult core-mechanic decision or during the cross-lens audit. These are working
questions for this skill, not universal laws or a scoring system. Pick what helps the author's
idea; do not turn the list into an interview script or add document fields.

For a concrete move, load only what fits: [core-experiments.md](core-experiments.md) for finding
an interesting action, choices or repetition; [feel-experiments.md](feel-experiments.md) for
sensory response, space and small measurements. These optional tools also support targeted audits.
For horror, use [horror-playbook.md](horror-playbook.md): relate the action to the intended tension,
curiosity or relief; do not require every repetition to feel pleasant or every short story to replay.

Claims about how players will feel or behave remain hypotheses under
[parking.md](hypothesis-log/parking.md). A test supplies evidence within its conditions, not a
universal verdict. A narrated round can expose unclear choices; it cannot establish enjoyment.

## Repetition: what remains interesting?

At Step B (§3), imagine the first action and the tenth. What can the player notice, choose,
express or enjoy now? Learning is one possible answer; pleasing movement, atmosphere, ritual
or making something personal may matter even when the action is familiar.

If repetition feels dull, consider alternatives before adding depth: the choice may be exhausted,
the consequence hard to read, the wait too long, or the sensation unlike the owner's fantasy.
Ask about a concrete moment, rather than diagnosing boredom from a label.

Offer a small comparison that separates plausible explanations: keep the choice unchanged and
try clearer feedback, or keep feedback unchanged and vary the choice. Observe what players do
and ask what changed for them. A better second attempt alone does not identify the cause;
practice, novelty and presentation may differ too.

## Motivation: what is the player choosing to do?

At Steps B and F (§4), ask what is appealing about the activity itself and what the reward adds.
Could a player choose a different approach and still enjoy it? Do not require a minimum number
of motives, reject a quiet activity for lacking mastery, or assume a badge makes it empty.

Distinguish wanting to return from feeling obliged to return. Describe possible benefits and
costs of expiry, scarcity or competition for this audience; a category name proves neither.
Check what the player knows before leaving that could prompt another visit, without inventing
an appointment. Curiosity, an unfinished creation and companionship are possibilities, not slots
to fill. Compare a proposed incentive with a simpler version only when that uncertainty matters;
keep actual return behaviour separate from a stated intention to return.

## Agency, company and feel: what changes the experience?

At Steps E (§2) and G (§5), ask whether the player can understand a consequence, make a meaningful
choice, or express the intended fantasy. When others are present, what can players notice or do
for each other? When nobody else is there, what remains enjoyable? Preserve “fun alone, better
with friends”; do not require every psychological need to be met in every session.

If players hesitate or disengage, possible explanations include unclear feedback, awkward
controls, unwanted pressure or simply a different preference. Do not infer a missing social
system from disengagement alone. Try the uncertain moment with an empty scene and, if relevant,
a second player. Record what each condition actually showed, including limits of a self-test.
A leaderboard, favour or cosmetic is an option whose effect needs checking, not a reliable lever.

## Cross-lens audit

During phase 3, inspect the draft through the questions above. Report only consequential gaps:
what is claimed about enjoyment or return, what else could explain it, and what small experiment
could help decide? Reuse existing hypotheses; do not create a row for every alternative thought.
An unresolved claim may remain a `TBD:` with a way to learn, or an explicit accepted risk.
This pass advises the author; it does not add a submission gate.

## Background and provenance

Earlier versions drew on Raph Koster's *A Theory of Fun for Game Design*, Yu-kai Chou's
*Actionable Gamification* (Octalysis), and Jamie Madigan's *Getting Gamers*, through an adaptation
in `decentraland/dcl-army-of-darkness`. These are intellectual references, not authorship claims
for the questions above. This revision replaces the book-by-book digest with applied questions;
it is not a verified summary of those books or a declaration of rights clearance. Source and
permission review remains open in the project's G28 provenance record.
