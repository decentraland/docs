# Section Map — Step B — §3 Core Loop

A step of [../section-map.md](../section-map.md) — its preamble applies here.

The spine. Everything below depends on it, so it is never deferred — and it comes before the
committed promise, because the promise's `[main verb]` *is* this section's verb. Asking for a
25-word promise first asks the owner to write a slogan for something they have not designed yet.

"Never deferred" binds **you**, not the owner (hard rule 8): if they skip the core loop anyway, go
where they pointed and park nearly everything downstream as `[OPEN: waiting on the core loop]`.

**Stage-aware:** at stage 1 this step resolves the verb, why it feels good the *first* time, and
**a coherent intended loop** — each step, what marks one completion, what outcome follows.
Do not force a decision the owner wants to test first: show that beat as open in the read-back
and keep the surrounding experience understandable.
A beat is a **decision, not a measurement**: Step C can write the promise from the intended loop.
Keep supplied durations as targets or attributed measurements; if unknown, leave them `TBD:`.
They need not wait for proof of fun, and need not be chosen now. Two guards: a beat you
inferred rather than heard is `[agent-decided]` or an open question, never an unmarked row; and
**leaving this step takes a read-back** — the whole loop in one message and their yes.
This checks the assembled loop, not permission to save its already accepted parts; follow the
section-map write-before-next-question sequence from the first answer. The first
time the owner calls the loop fun, offer a word run ([interview-moves.md](../interview-moves.md))
before the section closes.

The intended reason the tenth repetition remains interesting belongs in this early concept,
not in deferred measurements: what changes, what can be learned or expressed? Use the author's
idea, leave an unknown honest, and park the claim for testing. This is repeat-play appeal,
not a demand for next-day retention systems or ten authored pieces of content.

- **Explore one unanswered beat per turn.** The following is coverage to build from their story,
  not a questionnaire to send at once: what does the player repeatedly *do*? 3–5 steps, verbs not
  features — the template's
  table wants, per step, the input, what the player sees or hears, what changes, and **why do it
  again**; then **what marks one complete loop and what outcome follows** — the beat the steps end
  on. Then the numbers: how long is one complete loop (if over 90 seconds, where is the earlier
  payoff?), the shortest satisfying visit and the typical session, and **why repetition 10 remains appealing** — what changes or stays enjoyable once authored content is familiar? Then the
  decision question: what can the player choose, time, coordinate, or express — "repeat for a larger
  number" is not enough.
- Before recommending a load-bearing verb, apply [platform fit](../platform-fit.md): can the
  intended input, scene control and visible response deliver this sensation on the target client?
  Keep an unresolved dependency explicit; do not design the rest as if it already works.
- Ground the first repetition in one **solo moment**: action, response, space/mood and what makes
  another try worthwhile. Use the author's existing idea; this is not an extra questionnaire or a
  demand for lore. Do not use future social systems to fill an empty core; note the intended
  social improvement briefly and leave its detailed design for its stage.
- For an early feel hypothesis, name the response needed to perceive the action and what can
  stay placeholder. A small sound, light/change of shape or suitable existing asset may be
  enough; verify platform support and asset terms when building. Do not prescribe an effects
  list or defer all sensory feedback to polish. The creator can build the test themselves.
- **Good:** Verbs a player would use. 30–90 s per cycle. A named reason to repeat: variation, skill, expression,
  sensation or another concrete appeal in this game.
- **Smell:** Loop steps that are systems ("the economy runs", "the leaderboard updates") rather than
  player actions. No cycle length. "It's fun because there's a lot to do."
- **Pillars close this step:** 2 or 3 short phrases the owner protects when scope pressure comes.
  The template's test is the interview question: remove a pillar — do you get a different game? A
  pillar that changes nothing when removed is decoration.
- **Load:** [core-loop-and-ftue.md](../core-loop-and-ftue.md) · and, for a core-mechanic decision worth
  getting right, [design-lenses.md](../design-lenses.md) — what remains interesting at repetition 10,
  alternative explanations for boredom, and a small test to tell them apart.
- **Park:** repetition-10 appeal remains untested intent unless supported by evidence. Create a
  hypothesis file only when [parking requirements](../hypothesis-log/parking.md) are met; otherwise
  keep the intent and open test in the section. Do not interrupt to earn a card.
- **The evidence rule applies** ([scope-and-evidence.md](../scope-and-evidence.md)): a past self-test is a
  limited reported observation, not proof of the current build; park the remaining uncertainty
  and offer the relevant test.
