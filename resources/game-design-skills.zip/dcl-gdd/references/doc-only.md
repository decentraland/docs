# Document-only sessions

Loaded from SKILL.md the moment the mode is set. It binds **your initiative only** (hard rule 8).

**Default:** continue the document without initiating a build/test detour, a mobile QR pass, or a
pause pending playable evidence — hard rule 6, the empty-disk offer in phase 0 (open the interview
instead), the phase-5 invitation and the gate's QR pass all stay silent. Ordinary rest breaks still
apply. Record the stage-1 *"cannot close on words"* limit as a flagged note
([stages-and-gates.md](stages-and-gates.md)), never an offer. Park hypotheses exactly as always and
keep their markers and source sections: untested claims never block the next document step, and any
later cascade stays findable. Word runs and open arithmetic are words, not prototyping — the mode
never silences an interview move ([interview-moves.md](interview-moves.md)).

The [early HTML offer](stages-and-gates.md#the-html-render) is a document move, not a
build detour. Offer it when the concept is showable; do not wait for the stage-completion
exception below or for playable evidence. Refusal means continue the document.

**A Verify entry (route 1C):** report the log state without a handoff or repeated interview.
The document is already full: run phase 3's audit and finalization if unfinished; if already
finalized, use the closing move. Parked hypotheses may remain untested. The stage-completion
offer below belongs to an interview reaching that boundary, not every re-entry into a full GDD.

The owner's request to stop answering or receive a draft overrides automatic continuation into
later stages or finalization. Use [delegation](interview-moves.md#delegation-without-a-completion-treadmill);
doc-only is not permission to settle deferred design choices or require their immediate sign-off.

Two exceptions:

- **The owner asks to build** — *"let's build this one"*: honour it immediately, as a one-off; the
  controls card is unchanged. When they return from the build, ask once: *"continue document-only,
  or with prototyping from here?"*
- **The current stage's section set is written** — no `[OPEN]` left (`TBD:`, `[HYPOTHESIS]` and
  `[agent-decided]` may remain) and only untested hypotheses left: say so and offer — once — the
  switch to `dcl-prototype`. The set, not sections 0–9, or the exception never fires. **If the owner
  declines, continue into the next stage's set** if one remains: their mode choice is standing
  "go on in words". After the final set, run phase 3's audit and finalization; never invent a
  fourth stage or re-ask answered questions.

**End the session** with the state of the document and the next document step — on a finalized
document, the closing move ([finalization.md](finalization.md)) — plus the log status line, with no
invitation attached.
