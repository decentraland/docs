# Social by Design

Loaded at Step G (§5). The template's definition is the frame: *social gaming is play whose value
depends on other people being present, recognizable, and consequential.* The program requirement:
**Fun alone, better with friends — designed, not hoped for.** Hoped-for social is solo play with
strangers in the room. The ladder is **present → recognizable → consequential**: place the design
honestly and support the step it claims. Co-presence can pass; "these particular people" is the
top, not the entry bar. The [playbook's standing rules](playbook.md) apply to platform facts.

Skipping and `TBD:` are legal. Ask the hardest rows first; do not grind through all nine.
Independent progress or protection from interference does not mean "no social features". Leave
unmentioned social choices open; do not record "co-presence only" as the owner's decision.

## The loop and the disappearance test

`A signals or starts → B responds → they achieve something together or competitively →
shared or visible consequence → reason to regroup`.

The response must be **voluntary** and change another player's options, outcome, reward, status,
relationship or moment-to-moment play. A forced interaction alone is not a social loop.

**If every other player vanished, but their traces and data stayed, what breaks?** Existing scores
and traces stay available; distinguish losing live interaction from losing future updates. "Nothing" is an
honest, passable answer for a solo game with social evidence — but cannot coexist with a §4 crew hook
or a §5 loop claiming otherwise; catch that contradiction here.

## Recognition and continuity

Where does a player learn another player's **name**? What persists between them — role, rivalry,
routine, reputation, obligation, shared memory — and how does it change a later session?
"Marta beat your 47.2" starts a relationship; an anonymous rank change does not.
If Alice and Bob are interchangeable, the partner is traffic, not a person. A returning player
recognized by nobody has no social reason to return; §4's named-rival hook depends on this row.

For a socially flat design, offer **one** pattern, not a redesign: stable cohorts of roughly 10–20
for weeks; "X beat your ghost" plus "Marta 4–3 Bay"; a duo streak with the same person; remembered
events ("Carlos finally beat Maya after six days"); my rivals' ghosts instead of the global top.

Optional coaching above "consequential", **never a template requirement**:
creator authors conditions → players author the event → community carries its meaning/history →
creator or host observes something → responds next time. Fill each link with something concrete.

## Solo means worthwhile, not merely possible

With nobody else present, describe one satisfying moment: action, readable response, a meaningful
choice or discovery, and a reason to continue. Mood and feedback belong to that experience too.
Being able to survive, grind, wait or invite someone is not evidence that it is interesting alone.
High difficulty can be deliberate; judge the intended experience, not ease or theoretical winability.

The disappearance test above measures social dependence; it does not establish solo enjoyment.
Traces from earlier visitors can help, but say what a first visitor gets before such traces exist.
Then name what another player improves. Do not solve the gap by silently adding bots, a separate
minigame or more systems. Preserve the author's idea: discuss the mismatch and smallest candidate
change, or leave it explicitly unresolved. A social-only concept gets no automatic exemption.
Solo enjoyment stays a hypothesis until a relevant playtest; a written scene is not validation.

## Quiet hours are the baseline

Most scenes sit at **0–3 concurrent players**. Test claims there before event peaks:
*"What does your world look like at 4 a.m. with 2 players?"* Silence is a failing answer; a design
that only works at peak mostly does not work. Other avatars can be present regardless of the
intended design, so always answer what a bystander can **see** and **break**.

Ways a second player makes play better:

- **Group-scaled rewards:** the same act pays more together; two is already a group.
- **Multiplayer-only moments:** two-lever door, carry, pass, vote. Use sparingly; a critical-path
  dependency blocks quiet-hour play.
- **Competition:** a comparable score makes a race or board possible; storage, ranking,
  synchronization and abuse handling still need a scoped implementation estimate.
- **An audience:** something worth watching, with a performer who knows they are watched — the most
  under-used pattern on the platform. Effort depends on what spectators must see and receive.

Ways a lone arrival finds interaction by design, not luck:

- **Async traces:** boards, ghost runs, builds, messages or marks left by earlier players.
  They make a 1-CCU world feel inhabited at near-zero ongoing cost, but must sit on the loop's path.
- **Spawn near activity**, facing it, instead of at the parcel edge.
- **Concentrate the space:** three people in a small area beat twelve in an empty-looking one.
- **Schedule a peak window:** Friday 20:00 UTC gathers scattered visits and supplies a §4 event hook.
- **Two-second social verbs:** wave, challenge, pass, gift, high-five — usable on a stranger without
  coordination, chat or explanation. Chat alone is a text box, not a social verb.

## Player counts and joining

The quiet-hours row carries four load-bearing values: what a solo player can do, the **social
threshold**, ideal group, and **target player count**. Week 2 tests at the threshold; §6 measures
performance at the stated target load (program baseline: up to 20); §8 explains how the first group
reaches the threshold. Keep target capacity separate from tested capacity. A measured count names its source and test
conditions; no test means "not tested", not a copied target. A multiplayer session does not by
itself prove FPS at that population, and a future FPS test does not erase an earlier playtest.

A newcomer joins meaningfully within **30 seconds**, without voice or a shared language:
whom to join, what role to take, how to coordinate. A late arrival contributes immediately;
a departure or griefer must not break everyone else's round — a design where a leaver breaks the
round fails at Decentraland's real concurrency, not just at the review.

## Visibility, invitations and stories

- **Bystander test:** what can someone understand by watching for five seconds?
  Visible play teaches ([core-loop-and-ftue.md](core-loop-and-ftue.md)) and spreads the game;
  the interesting part hidden in a panel does neither.
- **Bring-a-friend:** what in the game makes an invitation useful? A second person needed for a
  desired act, "both earn double", something unlocked together, or an immediate newcomer gift.
  A share button alone is not the answer.
- **Memorable moment:** name a specific screenshot or clip, then the systems it needs. If no moment
  can be named, the experience produces no stories, and stories are the only distribution channel a
  small experience has.

Social ties support late retention: friend count predicts longevity better than achievement at high
engagement, and ungrouped players abandon more. But **churn is contagious**: a four-person crew can
collapse within days of one departure. Prefer small, re-formable groups to one fragile community.

## Smells

- "There is chat" / "they can team up" standing in for design.
- Social data dressed as social design: boards or ghosts claimed as relationships.
- A crew hook unsupported by recognition or a viable social threshold.

## Park

- "Two players do better than one" — cheap desktop test with two accounts.
- "A stranger uses a social verb on another stranger in session one" — real people in a live World,
  usually the most optimistic claim in the document.
- "The world feels alive at 2 CCU" — walk the empty scene; do not leave this cheap test parked.
