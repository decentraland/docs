# Section Map — Step C — §1 Player Promise

A step of [../section-map.md](../section-map.md) — its preamble applies here.

Written from the verb Step B decided. **If the owner calls it the "hook", this is the field they
mean** — the pitch hook, distinct from §4's *return* hooks; use their word back to them. This is
where the promise stops being a working draft and enters the document — one pass, with the cap on.

- **Ask:** Fill in the promise shape: `You are [role or situation]. You [main verb] to [goal], while
  [distinctive tension or twist].` Maximum 25 words; the exact sentence shape is optional, the four
  pieces are not. One twist only. Then the test: could a stranger repeat it to a friend after hearing
  it once?
- **Good:** ≤25 words, names the role, the verb, the goal and exactly one strange thing. Survives
  being read aloud.
- **Smell:** Adjectives nobody would claim the opposite of — "immersive", "unique", "fun". Five
  twists. A genre label with "with a twist" appended and no twist named.
- **Cap:** 25 words. Hard.
- **Use the shapes** in [player-promise.md](../player-promise.md) when they help: offer one or two
  short drafts grounded in the owner's idea. If their wording already works, use it. More shapes
  and real examples are available on request, not a required menu.
- **Load:** [player-promise.md](../player-promise.md) — shapes, the anchor technique, tests, the
  optional "Why this game" block.
- **Park the near-misses** ([interview-moves.md](../interview-moves.md)): one promise enters the
  document; offer to park every other keeper in `design/ideas.md` with its surface (tagline, trailer,
  audio).
- **The optional blocks are optional for real.** The one familiar comparison (`It's like [known
  game], but [one meaningful twist]`) is settled one beat later at **Step D**, from a real
  comparable — leave it open here rather than guessing. "Why this game" is 2–3 sentences about why
  the *owner* wants to make it — skip it if the answer is generic; never invent motivation.
