# Section Map — Step J — §9 4 Week Plan (v1 scope)

A step of [../section-map.md](../section-map.md) — its preamble applies here.

- Build the plan from the chosen playable scope. If the owner raises affordability or asks for
  an effort estimate, apply [funding and scope](../funding-and-scope.md); no compulsory budget
  or team-hours interview. Unknown production details may stay TBD for program review.
- **Ask:** what is playable at each milestone, per week; the **live-ops block**; the actual **scope cuts**, if needed
  (the twist never among them; which might return later — a cut parks in `design/ideas.md` marked
  `cut from §9 scope`); the top risk and its fallback. The dates, the block's four lines, the cut
  rules and the hours arithmetic are in [scope-and-evidence.md](../scope-and-evidence.md) — loaded at
  this step.
- **Good:** A clear playable outcome, real dependencies and chosen deferrals. If estimating effort,
  use stated assumptions. Cuts preserve the core; a named risk has a plan B.
- **Smell:** Oversized work with no trade-off. Invented cuts to fill a quota. A wish list per week. Weekly-content promises from a
  1–2 person team.
- **Non-goals — ask next to the cuts, optional:** any standing `never X, because Y` lines (0–3). A
  *cut* is wanted-and-deferred — it has an expiry, v2 may return it, and it proves scope realism. A
  *non-goal* is identity through negation — no expiry, a pillar with a minus sign. A non-goal is
  legal only if it has already **refused something concrete** — an idea, a mechanic, a comparable;
  a generic "not boring" refuses nothing. Never press for them: an empty optional slot is itself
  informative. The template slot holds the current truth; `design/decisions.md` holds the history
  and the why.
- **Load:** [scope-and-evidence.md](../scope-and-evidence.md)
