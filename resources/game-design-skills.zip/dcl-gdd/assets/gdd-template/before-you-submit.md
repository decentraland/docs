## Before you submit — self-check, delete before submitting

*The criteria and thresholds below are the program's — you do not invent a measurement framework, and the [dashboard](https://decentraland.zone/creators-data/dashboard.html) already tracks return for you. Do not plan around custom in-game tracking.*

| Criterion | Decision rule |
|---|---|
| **Immediate comprehension** | The 5/10 rule (Section 2): once playable, at least 80% perform the first useful action by 5 seconds and state the immediate goal by 10 seconds without help. |
| **Voluntary continuation** | Without prompting, players choose another loop or round, invite, regroup, or ask when they can return (Sections 2, 4). |
| **Progression and return** | Progress changes later play (Section 4); the v1 floor is >10% first-week return (dashboard D7). |
| **Intentional social play** | A voluntary action changes another player's play, options, reward, status, or relationship; joining or leaving does not break play (Section 5). |
| **Social continuity** | Returning players recognize people, roles, relationships, routines, reputation, or shared history; at least one changes a later session (Section 5). |
| **Visible, shareable play** | Nearby users can understand the activity, and play creates a specific moment worth sharing (Sections 5, 7). |
| **Discoverability Bar** | Packaging, spawn, and first-minute play promise the same experience, with no unresolved IP or Content Policy issue (Sections 1–2, 7). |

*Program-level target — above the v1 floor: **more than 20% first-week return (dashboard D7) and meeting the Discoverability Bar.***

- [ ] My player promise names a role or situation, a verb, a goal, and one meaningful distinction — and my spawn view and first-minute play deliver that same promise
- [ ] I checked the current game, scene and World names, branding and used content for IP & Content Policy issues; I noted permission references or uncertainties and named a deployment target — or wrote `TBD:`
- [ ] The first useful action needs no mandatory reading; How to Play is exactly 3 short bullets
- [ ] My core loop is 3–5 verbs with a named source of freshness at repetition 10, and each pillar would change the game if removed
- [ ] My D1 sentence points to one of my 2 selected hooks with a concrete trigger or timing — not "it's fun" — and progression changes a later decision, capability, status, or role
- [ ] I designed the social loop, the player counts, quiet-hour play, and drop-in / drop-out — and returning players can recognize something that persists between them
- [ ] My primary player is specific
- [ ] Every core-loop verb has a touch mapping; I named my top risk and its fallback
- [ ] My scope fits the time we choose to invest; any cuts preserve the core promise
- [ ] I deleted the intro, everything written in italics, the Glossary, and unused placeholders; I kept headings, labels, tables, and my answers

---

**One last question** *— optional, one line. Which section was hardest or made you stop — and why? That answer helps us improve these questions.*

[Your answer — or delete this block]

*What happens next: the Creator Success team reviews your GDD, may invite you to a short call, and responds with a decision or targeted questions. You get feedback either way.*

---

