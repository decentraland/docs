# Horror — space, senses and the player's account

Load for a scene whose fear depends on perception, movement or recovery. Pick one useful prompt;
do not turn these options into required features. Start from the author's imagined moment.

## What can the player notice and do?

For a reveal or pursuit, trace what enters the view as someone turns, approaches or retreats.
Could they miss the event while making a reasonable choice? Try the same small encounter from
another approach. A composed image does not establish the experience of moving through it.

Restricted control can express vulnerability; it can also make someone fight the interface.
Bycer favours approachable movement, while Taylor and other critics discuss restriction as an
expressive tool. Keep that choice open. Ask which limitation the player understands and what
decision it creates. Try removing one restriction; easier control does not automatically weaken
horror. Check load-bearing camera, movement and sensory effects through [platform-fit](platform-fit.md).

## Hide the threat without losing the action

When a scene feels flat, ask what remains just beyond sight and what the player can still use
to orient themselves. A wall or interrupted view may serve the idea without making everything
dark. Compare one landmark or clearer interaction cue with the existing scene. Notice whether
the player keeps investigating or merely repeats an unsuccessful route.

Being lost can sustain uncertainty or exhaust interest. Before adding a pursuer to fix wandering,
ask what the player thinks they are seeking. Revisit a familiar place with one meaningful change
if recognition matters. Looking towards a hidden area shows attention, not proof of fear.

## Decide what sound promises

For an important sound, ask what someone might infer about its source, distance, danger or the
character's state. Does music confirm safety, leave it uncertain, or contradict the action?
Try a brief cue sequence with an expected transition changed. Afterwards, ask what the listener
expected next. Repeated false alarms may instead teach them to ignore the channel.

Clear warnings and uncertain sounds serve different aims; neither is inherently scarier. Consider
sound texture or silence as well as melody. Do not import a prescribed number of layers, pitch,
volume or a claim that music overpowers every other effect. Try the intended listening conditions;
painful loudness and missing information are not successful scares. For a practical sound or light
probe, reuse [atmosphere trials](../../dcl-prototype/references/atmosphere-trials.md).

## Let recovery mean something

If shelter, checkpoints or saving matter, ask what is protected: the character, earned progress,
or simply a moment to think. If a refuge changes, what signals that change and what can the player
do? Compare a return journey and a retry, including the work they must repeat.

Saving can release tension or create anticipation; restricting it can also waste time. Choose for
this experience. Check that an attempted escape or saved state does not strand the player in an
unwinnable loop. These are design questions, not a demand for a save system in every short scene.

## Use a probe that can carry the intended feeling

A spoken round can explore expectations and choices; it cannot establish the effect of walking,
timing or sound. Include only the sensory cues needed for the current question. An unfinished
atmosphere is not proof that the idea fails; adding every missing production layer is not the answer
either. Let the author choose whether to explore now or leave the question open.

Afterwards, separate observed actions, the player's account and your explanation. Ask about a
specific moment without supplying the emotion. Silence can mean concentration, stress or confusion;
continuous commentary can change play. Note first exposure versus replay, company and listening
conditions. Retesting can examine familiarity, but cannot recreate a first surprise. A reaction
video, a gaze trace or a body signal alone does not distinguish enjoyable fear from frustration.

## Reading behind these prompts

Original coaching synthesis, not reproduced exercises or a validated fear test:
Joshua Bycer, *Game Design Deep Dive: Horror* (2022), §§4.3–4.4, 9.6;
Bernard Perron, *The World of Scary Video Games* (2018), chs.7–9, and *Silent Hill: The Terror Engine*
(2012), pp.81–85, 112–119, 128;
Simon Niedenthal and Laurie N. Taylor in Perron (ed.), *Horror Video Games* (2009);
Isabella van Elferen, “Sonic Descents,” in *The Dark Side of Game Play* (2015), pp.226–241;
Tracy Fullerton, *Game Design Workshop*, 5th ed. (2024), chs.7–9;
Jesse Schell, *The Art of Game Design*, 3rd ed. (2019), pp.484–494.
