# Section Map — Step D — Comparables (closes §8's comparables table)

A step of [../section-map.md](../section-map.md) — its preamble applies here.

The twist now exists, so all three rows of the template's table answer in one sitting — including
*"what we will do differently"*, which is the promise re-read against someone else's game. Two
comparables — the template requires exactly two and no more. One from outside Decentraland; a second
from inside is **a plus, not a requirement** (two outside games are fine — hobbyist owners often
don't know the DCL catalog yet, and an invented Decentraland comparable is worse than an omitted
one).

- **Ask:** Which game outside Decentraland is closest to what you want — and, if the owner knows the
  catalog, which Decentraland experience? For each: what worked, and — the useful half — what did
  **not** fit this audience or context? Then, with the twist in hand, what you will do differently —
  and re-read §1 against it. **The played-check is part of the ask:** before any row is written,
  ask which of the candidate titles they have actually played — the table only holds what they
  saw themselves.
- Reuse inspiration already named at Step A. Ask only what is missing; do not treat your own
  earlier comparison as the owner's observation or make them repeat what attracted them.
- **Research both titles as this step opens** (hard rule 5), so the question already contains what
  you found — never as a precondition to the first interview question.
- **Your research stays in the question, never in the table:** rows are written from what they say
  back — a nod to your summary is `[agent-decided]` (agreement is not observation). Swap a title they
  have not played for one they have.
- **Comparables explain a design choice.** Keep the owner's specific observation, the limitation
  relevant here, and what this game changes. A comparison should help imagine the proposal, not
  substitute another game's identity or imply sales from a similarity. Probe: "Which part would
  you keep, and which part would not suit your players?"
- **Good:** Two named, specific titles the owner has actually played, each with an honest failure. A
  "differently" row that points at the twist rather than at being better.
- **Smell:** Fortnite / Elden Ring / "an MMO" as a comparable for a first project. A "what does not
  fit" row that is empty or flattering — the template warns against making the comparable sound
  better than the owner's own game. "We do everything better."
- **Then close §1:** decide its optional familiar comparison now that a real comparable is on the
  table — take it or drop it, and §1 is written once.
- **Not this step:** the rest of §8 — primary player, arrival context, deliberately-not-for. Those
  depend on §5's social threshold and close at Step I.
