# Exploring feel — from an impression to a small test

Use when the action is understandable but its sensation, atmosphere or feedback is uncertain.
Pick the relevant comparison, not a checklist. “Feel” here includes control, sensory response and
the author's intended mood; it is broader than Steve Swink's particular definition of game feel.
This is optional experiment design, not a requirement to build or instrument before submission.

## Turn an adjective into a moment

Keep the author's image: “gentle”, “heavy” or “alive” is a starting point. Ask what the player
should notice when they begin, continue or stop the action. Explore one response that could make
that image perceptible, without inventing lore or changing the accepted mechanic.

Fictional example: in a floating seed garden, “gentle” might mean a seed acknowledges a nudge
quickly, then drifts to rest. That is a proposed response to try, not a proven recipe. A slow
movement and a delayed acknowledgment are different design choices.

## Separate a control problem from a challenge

If a player struggles, watch the troublesome attempt. Could they see the target, understand the
result and tell whether their input registered? Compare clearer acknowledgment before assuming
the challenge needs easier numbers. Conversely, deliberate, readable wind-up may be part of the
challenge. A complaint is evidence of their experience, not a diagnosis of its cause.

Apply [platform-fit.md](platform-fit.md) before recommending a load-bearing control, camera or
animation change. Distinguish scene-controlled objects from the platform avatar and camera. Do
not promise custom handling of either; if control is constrained, explore the space or feedback
around the supported action. Desktop evidence does not establish the same feel on touch.

## Try the action in its space

An empty test area can hide the issue. Compare a few relevant arrangements using the same action:
near/far targets, narrow/wide passages, clear/cluttered views. Observe hesitation, overshoot or
missed cues relative to the intended experience. If appropriate, change spacing before changing
controls. More difficulty is not the goal; the right relationship depends on the fantasy.

## Give the prototype enough sensation to answer

Choose a small response that carries the intended meaning: a sound, a change of light or shape,
or a suitable placeholder. Check support and asset terms when building. Compare one cue at a
time where practical; keep essential information available so “effects off” does not secretly
become “instructions missing”. If sound improves the result, it may improve clarity, rhythm or
atmosphere; that alone does not identify the original problem.

Check what the cue invites the player to expect. A visibly soft object with a harsh response may
be an intentional contrast or a mismatch. Ask which the author wants rather than enforcing
realism. Avoid assuming more particles, shake or loudness improves the experience.

## Use presentation as a design choice

If the promised physical sensation is costly or unsupported, compare a different presentation
before expanding engineering. A fictional seed moved by visible wind may set different expectations
from a photorealistic hand grasping it. Ask which interpretation preserves the author's fantasy;
stylisation is an option, not an automatic downgrade or a guarantee of lower cost.

An empty world can mean nobody is present, travel has no interesting purpose, or actions receive
little response. Try a short solo route: what invites attention or manipulation along it? A smaller
space or responsive surface may help a spatial problem; it does not manufacture social connection.
For each added sound, motion, light or effect, ask what it communicates and whether it obscures
another cue. Deliberate contrast can be expressive; realism and uniformity are not universal goals.

## Measure only what answers the question

Separate observations from impressions. If timing matters, a recording showing input and the
first visible response can provide an estimate; note frame rate, counting uncertainty and the
build/device. A recording of the screen alone cannot establish physical input-to-display delay.
For networked play, distinguish immediate local acknowledgment from authoritative outcome.
Do not turn a book's timing figures into universal limits or DCL guarantees.

For spatial or repeated actions, useful observations might be overshoots per attempt, time spent
waiting, or which approach a player tries next. “Felt calmer than the previous version” is a
player report, not a measured percentage of calm. Faster or more successful is not necessarily
more enjoyable. Record the version, conditions and what changed with the relevant evidence;
custom telemetry is unnecessary when a short observation answers the question.

For a specific timing, parameter or instrument question, read [feel-instruments.md](feel-instruments.md),
including attributed numerical prompts and their limits. Do not load it for an ordinary concept chat.

For a handoff to a prototype, carry the uncertain moment, supported control path, response worth
preserving, comparison and what its outcome would leave unknown. Use the existing hypothesis
contract, not a new mandatory form. A solo test comes first when testing solo appeal; another
player must not conceal an empty-world problem.

## Intellectual background

Original practical synthesis informed by draft wiki readings of Steve Swink, *Game Feel* (2009):
pp. 24, 45, 83–85, 122–126, 147, 155–170 and 269; and Jesse Schell, *The Art of Game Design*, third
edition, pp. 53–55. We use these as prompts for observation, not validated causal rules. No timing
threshold, book diagram or catalogue is reproduced. The example and DCL adaptation are ours;
source locators have not been independently rechecked against the books in this iteration.
