# Core Loop and the First Minutes

Loaded at Step B (§3) and kept for Step E (§2): §2, §4, §5, §6 and §9 all grow from the loop.
The [playbook's standing rules](playbook.md) apply to facts and examples.

## §3 — verbs, repetition and pillars

A loop step is something a **player does**: grab, throw, stack, race, trade, plant, dodge, vote.
"The economy rebalances" is a system action. To extract a verb from a feature, ask
*"What does the player's hand do?"* Features with no verb are outside the loop, often outside v1.

Write **3–5 steps with a closing arrow**. The table supplies it through input → what the player
sees or hears → what changes → why do it again. That last column must give a reason to return,
never merely "to progress"; without it, this is a sequence that ends.

- **Cycle: 30–90 seconds.** Longer cycles must name an earlier payoff; a mobile session needs enough
  repetitions to build skill and rhythm.
- **Session: minutes, not hours** — several short sessions beat one long one, for retention and for
  the platform. Name the shortest satisfying visit and the typical session. Design the exit as well
  as the entrance; carry these numbers into §4's hook rhythm.

**Why is repetition 10 still fun?** The answer is always a hypothesis: name what changes or what remains worth doing.
Variation is one route; familiar sensation, expression or ritual may also matter. Possible routes:

| Source | Needs | Cost or constraint |
|---|---|---|
| Other players | Concurrency or async traces | Needs viable participation; §5 must support it |
| Randomness: layout, spawn, order, modifier | A generator and a floor on bad rolls | Needs readable outcomes and useful agency |
| Rising difficulty | A tuning curve and a worthwhile fail state | Requires tuning; ends when the curve ends |
| New combinations | An expanding toolkit; content per unlock | Content and interaction costs can grow |
| Skill expression | Depth in one verb and visible mastery | Depth and feedback require iteration |
| Escalating stakes | Persistent state to risk | Depends on §4's persistence and chosen stakes |

“It is procedural” alone does not explain appeal; more authored levels require a supply of content.
**Try the smallest meaningful experience:** removing extra goals or rewards can reveal the pleasure
of an action. It is a comparison, not a rule that every game must work without purpose or sensory
feedback. Keep what is essential to the intended experience, then test what actually contributes.
A pleasant repeated ritual is a valid hypothesis; it still needs evidence and is not proof of return.

**Close with 2–3 pillars:** short phrases protected under scope pressure. Remove one: does it become
a different game? If not, it was a feature — a pillar whose removal changes nothing is decoration, and
the pillars earn their keep at the §9 cut list. Every section serves at least one pillar; §9's
standing non-goals are pillars with a minus sign and must not contradict them. "Great graphics" and
"deep progression" are not useful pillars. Ask which chosen feature protects each pillar and
which actual rejected idea would have weakened it. For a fictional ferry game, a pillar such as
"navigate by listening" would affect routes, feedback and obstacle design; it is not just a slogan.

**Make the loop visible:** when a list hides a dependency, sketch the player's actions and the
changing state as arrows or a few panels. Use this game's situation, not another game's diagram.

## §2 — the first minutes, written as "you"

Second person, present tense: **180 words** across 0–5 s, 5–10 s, 10–60 s, 1–3 min, 3–10 min,
and the natural stopping point. Narrate what happens, not the systems behind it; the §1 twist must
appear in this first session. The point is not the prose: writing a session you have to narrate
concretely is the fastest way to find out whether the loop is real — for the owner and for the
reviewer.

### Seconds 0–10: action and comprehension

The **5/10 rule**: once the first minute is playable, at least 80% of playtesters perform the first
useful action within 5 seconds and state the immediate goal within 10, without help. Ask what in
the first camera frame teaches the verb:

- one dominant affordance, large enough to read on a phone;
- other players visibly mid-loop — the best tutorial in any multiplayer experience, and free;
- motion where the action is — the eye goes to movement before text.

Instruction signs, tutorial NPCs, UI narration, lore and walking before acting are **smells, not
bans** — name them, never refuse a design over them. Fix the frame, then shrink any hint. The bar is
no mandatory reading; P3 fails on incomprehension, not text ([preflight.md](preflight.md)).

### First minute: legible reward

Reward within sixty seconds: sound, motion, a number or a state change the player notices.
The program's publishable bar asks for sound and a tooltip on **every interaction**.
For each verb, show both success and failure, readable on a phone at arm's length — a loop the
player cannot read is a loop they cannot learn.

### First ten minutes: close a goal, open another

At 1–3 minutes, complete a loop; at 3–10, offer the first meaningful choice or escalation.
One goal closes and the next is visible, so leaving costs something.

At the natural stopping point, show what is completed or saved and **tomorrow's reason to return**.
A Sunday league reset cannot pull a Wednesday visitor back unless they see the league before
leaving — the most common silent break between §2 and §4; check it explicitly.

### How to Play

Exactly **3 bullets, at most 8 words each**: main verb + immediate objective; progress or success;
how another player changes the experience. If one cannot be written, §3, §4 or §5 is undecided —
say so instead of padding it.

**Let the reader imagine acting:** use the owner's setting and a visible response, not a tour of
systems. Fictional illustration: "You ring the ferry bell. A reply comes from the fog on your left;
you turn toward it." The episode explains an input and a cue without adding a tutorial paragraph.

## Park

- **One meaningful repetition is enjoyable** — test the intended action with the cues and purpose it needs.
- **Repetition 10 is still fun** — the core-loop rung's reason to exist.
- **The 5/10 rule** — a greybox and three testers; untested is legal here, and the template says so.
- **Cycle length** — measure it instead of arguing about it.
