# Horror — shape the intended experience

Load for a horror concept, a question about tension, or a targeted audit. Use one relevant lens,
not this whole page as an interview. These are options across different kinds of horror.

For a deeper question, load only the matching page. Offer a relevant lens when it helps the
author's current idea; do not require a tour of the library or a separate approval for each lens.

| Current question | Optional playbook |
|---|---|
| Threat, player choices, pressure, repetition or company | [Tension and decisions](horror-tension.md) |
| Story, character, emotional tone, cultural meaning or film inspiration | [Fiction and emotional intent](horror-fiction.md) |
| Space, visibility, sound, controls or how to investigate the experience | [Space, senses and observation](horror-space-senses.md) |

## Start with the author's kind of fear

What moment matters: approaching something unknown, surviving pursuit, making a costly choice,
or laughing with friends after a scare? Follow their image before offering concepts. Keep several
directions open when they want to brainstorm.

Here, “find the fun” means finding an experience people want to engage with; moment-to-moment
comfort is not the only goal. Ask what the player chooses during that experience. A short story
can work without an endlessly repeatable loop; examine repetition only where the design uses it.
Combat, comedy and company are compatible with horror when they serve this author's intent.

## Choose a lens

**Anticipation and agency.** What does the player expect before entering, and why do they go?
Try changing the lead-up to one encounter while keeping its outcome. Ask what they expected
and why they continued. A pause may mean curiosity, fear or unclear controls. [Grip 2019](https://frictionalgames.com/2019-10-9-years-9-lessons-on-horror/)

**Useful clarity, uncertain consequences.** Which information makes the choice understandable,
and which uncertainty makes it interesting? Try a readable risk cue alongside an unpredictable
event. Mystery does not require hiding every rule. Darkest Dungeon's authors describe making
stress visible; this is a contrasting approach, not a reason to add a stress meter.
[Bourassa and Sigman 2015](https://www.gamedeveloper.com/design/game-design-deep-dive-i-darkest-dungeon-s-i-affliction-system)

**Vulnerability with something to do.** What decision remains when direct confrontation is
unwise? Try an optional discovery beside a route to safety; ask why the player approached or
left it. Either choice may fit the fantasy. Removing weapons is one option, not proof of fear.
[Morin 2015](https://www.gamedeveloper.com/design/horror-in-the-making-how-red-barrels-outlasted-i-outlast-i-)

**Pressure, relief and company.** Where can someone recover, notice a clue or help a friend?
Compare sustained pressure with the same encounters separated by calmer moments. For a repeatable
experience, try another pass: what remains a decision after the surprise is known? For co-op,
observe what players actually do for each other. A game-state intensity estimate is not a fear
measurement. [Booth 2009](https://cdn.akamai.steamstatic.com/apps/valve/2009/ai_systems_of_l4d_mike_booth.pdf)

**Systems competing for attention.** Is a resource, puzzle or combat task supporting the intended
feeling or consuming attention needed for it? Try removing one competing demand in a small
variant. A better second attempt may also reflect familiarity. Amnesia's cuts were project-specific,
not a rule against mechanical depth. [Grip 2011](https://frictionalgames.com/2011-07-amnesia-post-mortem/)

## Build enough to answer this question

For route or control questions, rough geometry may suffice. For an atmosphere question, include
the cues carrying it: perhaps actual sound, light contrast, obscured sightlines and a reason to
proceed. Add only what that question needs; a finished setting is not a prerequisite.
An incomplete scene's weak atmosphere does not settle the concept.
[Grip 2017](https://frictionalgames.com/2017-04-navigating-the-space-of-game-design/)
For a concrete build–play–adjust probe, use the prototype's
[atmosphere trials](../../dcl-prototype/references/atmosphere-trials.md); no handoff is required
just to discuss a trial.

Fictional probe: a player brings a borrowed key to a locked boathouse while a bell sounds from
inside. Test one uncertain moment, such as recognising where the sound comes from or deciding
whether to open the door. This is an example to adapt, not a proposed game for every creator.

Use [platform-fit](platform-fit.md) for load-bearing controls and effects. A dark enclosure,
handheld light, camera change or hidden avatar needs current SDK evidence and a client check;
none guarantees atmosphere. If the intended experience depends on company, a solo pass cannot
settle that question. Do not force multiplayer into an intentionally solo prototype.

After play, ask neutrally: “What did you expect there?” or “What made you turn back?” Keep the
observed action, the player's explanation and your interpretation separate. Walking instead of
running does not prove understanding; a scream does not prove sustained tension. Confusion,
unreadable space or unpleasant effects are alternative explanations, not diagnoses.

An exploratory try needs no invented scare score or H-file. Save its question, build, observations
and unknowns under the existing handoff contract. A registered experiment keeps its agreed
criterion. Neither a successful build nor a narrated scene establishes the intended feeling.

## Provenance

The linked developer accounts informed these original coaching prompts and fictional probe;
they are not reproduced methods or a complete summary. Their game-specific conclusions are
not universal thresholds. No source text, images or slides are bundled. For a horror-movie theme,
separate inspiration from use of protected characters, titles and assets under the existing IP check.
