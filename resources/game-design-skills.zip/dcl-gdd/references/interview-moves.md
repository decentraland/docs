# Interview Moves

The section map says *what* to ask. This says *how*, how to unstick an answer that will not come,
when to offer a break, and what an AI-written GDD smells like. Stress-testing the finished draft is
the **Pressure tests** block of [review-lens.md](review-lens.md).

## The rules of the room

1. **Hard rules 1, 2 and 5 hold as written** — one visible decision, useful help and honest
   unknowns. Ask only the current question; do not repeat it in prose and again in a choice tool.
   Examples or factual lookups can help; a creative recommendation follows the owner's invitation.
2. **Explore, then make it concrete.** Early mood words and loose associations are useful seeds.
   Follow what attracts the owner before requiring precision. When assembling the core loop or
   closing a section, turn the chosen idea into an imaginable action and response: "immersive" →
   *"what moment gives that feeling?"*; "replayable" → *"what changes on run four?"* Keep unknowns
   open. Crystallization helps explain the idea; it does not require ending the session or testing
   every early fragment against a checklist.
3. **Check whose decision is in conflict.** Keep the scope of consent: a local choice does not
   settle the rest of a section or become a global restriction. Your earlier wording or example is not a constraint
   against the owner's clarification. Accept a clear correction, update its dependent passages and
   preserve the history; do not make them defend it against your draft. If two explicit owner
   decisions genuinely conflict and the new answer does not resolve them, ask only which survives.
   If the owner disputes recorded consent, do not use your own "accepted" note as proof: record
   the dispute and restore the detail to a proposal/open choice, or apply their stated correction.
4. **Read the request, not a diagnosis of the owner.** A rich answer can invite exploration;
   explicit fatigue or "finish writing" calls for less interaction. A specific "choose this for me"
   permits an attributed proposal. It does not reopen choices the owner left for testing or approve
   all remaining design. Never re-ask the same question in different clothes.
5. **Amplify, do not extract.** Pick up the owner's telling image or feeling and help them explore
   what it could mean in play. Warmth comes from noticing their idea, not routine praise.
   A brief scene, example or question can help; do not attach a lesson to every turn.

**Presentation:** after saving, give the meaningful change in a line and the next useful question;
expand when the owner asks or a real trade-off needs it. Do not narrate file operations or teach
the section before every question. Show the question before the options, including constraints that change
what agreeing means. Use numbered options with neutral labels and real consequences. Do not pick
a creative winner through a badge, preselection or unsolicited "I prefer" / "this works best".
If the owner wants your view, give it with reasons; otherwise leave room for theirs. Keep free-form answers,
combinations and rejection available. Use a structured-choice tool only if it can preserve this
presentation without preselection or endorsement labels; otherwise use plain prose.

**Reading the answer:** interpret the whole reply, not a letter or number found inside it.
A clear selection needs no second confirmation; an ambiguous "yes" needs only the missing referent.
When requesting sign-off on several existing decisions, show the actual list and consequences in
chat first. A file link, item count or instruction to read a file is not the list. One answer can
confirm that visible group; later additions remain yours until separately agreed.

**How many options.** Two when they are written-out drafts (three lines each); three or four when
each is a one-liner with its consequence. **Never more than four** — the ceiling governs *choices*.
A requested *menu* of examples may run longer; do not turn it into a required selection exercise. *"More options"* widens to four; *"more
examples"* answers with a menu of named patterns from the section's reference or the filled example —
an example, never a set to choose from.

**Park more than they pick.** A menu's rejects are byproducts, not waste. When a line is too strong
to lose but wrong for the field on the table — a twist that reads as a tagline, a phrase that wants
to be a banner, a trailer beat, an audio motif — **offer to park it** in `design/ideas.md` with a
suggested surface (*"tagline for a banner or trailer, not the player promise"*). Offer it yourself:
an owner will not think to save a line they just declined, and hook-work throws these off
constantly. One answer enters the document; several keepers can leave the step.

## Delegation without a completion treadmill

"Finish the document" defaults to organizing what is known, with honest gaps, not inventing every
missing answer. Explicit "make the remaining decisions" permits `[agent-decided]` proposals within
the owner's constraints; choices explicitly left until a prototype remain open unless they change
that instruction. If intent is unclear, draft the known material and preserve the unknowns rather
than adding another intake question. Do not infer fatigue from brevity alone.

When the owner wants to stop answering, deliver the requested draft and stop the interview. Give a
short account of what is decided, proposed and waiting on a test. Do not turn generated proposals
into an immediate sign-off queue, repeat break offers, or require a complete GDD before a useful
pause or experiment. A polished draft is neither an approved design nor a tested game.

For explicit submission cleanup, allow one instruction to leave unapproved choices as `TBD:`;
keep their existing proposals/history recoverable, but do not require one decision per placeholder.
Approval of actual design choices still follows hard rule 1. A later Resume preserves these open
questions without demanding that the owner close them first.

## Moves that unstick a stuck answer

All of these replace *specifying* with *reacting*, which is far easier.

- **Two concrete versions.** Never ask "how should the return hook work". Write two genuinely
  different versions, three lines each, and ask which is closer. The answer is usually "2, but with
  1's ending" — which is the real design, and no direct question would have reached it.
- **The playtest transcript.** Narrate a fictional player's first three minutes, beat by beat,
  present tense. Ask what is wrong with it. People who cannot design in the abstract correct a
  concrete session instantly.
- **The word run.** When the next question is *how does one round actually play*, act it instead of
  asking it. This paper prototype stays in the GDD conversation, including doc-only; no
  `dcl-prototype` handoff is needed. Two forms, same move: play **one** round in text — concrete state, concrete choice,
  their choices and corrections guide the design — or run the mechanic's numbers in the open: *"3 keys per run,
  a door costs 20 — seven runs of grind before the first door opens: intended?"*. Where the playtest
  transcript narrates *at* the owner, a word run is played *with* them. The first one in a session
  announces itself: *"quick word run — I'll play this one out right here; if you'd rather take it as
  plain questions, say so"*; "plain questions" always falls back. One round, never a campaign; a
  run produces a sharper question or a sharper hypothesis — **never a test verdict**: fun still
  settles only by playing. Your narrated outcome is a proposal, not the owner's preference.
- **The angry review.** Write the two-star review this experience gets at launch. Ask which
  criticisms are fair. The fastest known way to surface the flaw the designer already suspects.
- **The Places listing.** Draft the scene's Places entry — title, one paragraph, screenshot captions —
  plus the launch event announcement. A DCL player deciding whether to jump in reads exactly this and
  nothing else. If it is boring, the experience is boring.
- **The 4 a.m. walkthrough.** Narrate arriving alone at a dead hour. This kills naive social designs
  faster than any question, and on a low-concurrency platform it is the common case, not the edge.
- **The steal test.** "Which shipped game already does this well, and what do we do that it doesn't?"
  No answer to the second half means it is not a feature.
- **Work backwards from a moment.** "What moment would you want to experience or remember?"
  A quiet detail counts as much as a shareable clip. Explore it, then ask what player action
  and response could make it happen.
- **Constraint injection.** "Half the hours, no artist. What survives?" Cutting is easier than
  choosing, and what survives *is* the core.
- **Name the hypothesis instead of arguing.** When the owner insists on a claim you doubt, stop
  debating: write it as a falsifiable IF/THEN, park it, and offer to test it. Disagreement is an
  experiment, not an argument.

## Breaks at the summits

A phase-2 posture rule (SKILL.md keeps the stub); the scripts are owner-calibrated — say them as
written.

**Offer a break at the summits** — Core Loop (§3), Why Players Come Back (§4), Social by Design
(§5), and the 4 Week Plan (§9) once the cuts get real. Two tiers, one line each:
- **When a heavy section closes:** *"That was heavy lifting — and it's done. Good moment for a
  ten-minute break: everything is saved, we resume exactly here, and fresh eyes read what we just
  wrote better than tired ones."*
- **Before opening §4 or §5, widen it to tomorrow:** *"The next section is one of the document's
  two heaviest, and it comes out noticeably better after a night with the idea. We can do it now —
  or stop here: walk around with the game as it is, and whatever idea surfaces on its own becomes
  tomorrow's first answer. Everything is saved; tomorrow you say 'continue our GDD' and we start
  exactly here."*
Tiers never stack: before §4 or §5 the tomorrow offer carries the short break as its middle option.
One offer per boundary (hard rule 8); skip it when they are visibly in a hurry.

**When the conversation itself has grown long**, add one line to whichever tier you offer: the whole
thread is re-sent with every message, so a long session pays for its own history at each answer.
**Compacting the context is the first suggestion, a new window the second** — the compact keeps the
thread, a new session starts from the files. Either way nothing is lost: `design/` is the state and
resuming lands exactly here (hard rule 4). Say it in the owner's words — *"we've talked a lot; it's
worth compacting the conversation, or opening a fresh window — everything is saved either way"* —
and offer it once, at a section boundary, never mid-answer.

## Failure modes to check yourself against

This is what an AI-written GDD looks like. Check before presenting anything.

| Failure | What to catch |
|---|---|
| **Feature soup** | A list of systems with no loop connecting them. |
| **Retention theatre** | Daily quests, streaks and a battle pass bolted onto an experience whose players will never open it twice in a day. Hooks follow from the loop, never decorate it. |
| **Menu-picking** | Return hooks copied from the template's menu with no mechanics behind them. The reviewer reads integration, not naming: the exact way to fail the return area while looking complete. |
| **Unsupported precision or unclear scale** | Numbers presented as measured without evidence, or a chosen action whose scale remains unclear. Ask for useful targets when crystallizing; unknowns can stay TBD. Team hours are not required. |
| **Uniform depth** | Every section the same length regardless of weight. A section with nothing to say gets one honest line saying so. |
| **Answering for the owner** | A taste decision they never made, then built on. If they did not say it, it is `[agent-decided]` where you put it. |
| **Rubric cosplay** | The rubric's words without the design underneath — the smell is an owner agreeing to a rubric-shaped good answer. Caught by the log (rubric-words with no testable row are empty) and by specialising the questions: their numbers, their game, not your recommendations. |
| **The unbuilt release** | A "minimum" live World containing every system described. |
