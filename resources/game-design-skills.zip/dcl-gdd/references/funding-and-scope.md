# Funding and scope

Read when funding, affordability or an effort estimate comes up; also consult the application
facts when completing the header at the end. Do not initiate a financial review, require hours
or budget figures in the GDD, or make agreement on scope a condition of helping submit it.
Discuss estimates in chat; include them in the GDD only if the owner wants them there. Keep
the chosen playable scope in the document. Program reviewers may help refine it after submission.

Creator Success supports early development, testing and validation of the studio's **own game
and IP**, which it can continue developing and monetizing. It is not a commission or a
client-services fee. Treat funding as a design and production constraint, not a commercial quote.

Fixed milestone funding: **V0: $1,000 · V1: $3,100 · V2: $2,800**.
These amounts and the ownership/scoping principle come from Bay Backner's *Funding and Scoping
Principle*, supplied by the program owner in September 2026. Primary public program reference:
[Creator Success onboarding](https://docs.decentraland.org/creator/studio-onboarding).
Checked September 15, 2026: onboarding confirms V0/V1 amounts; V2 here comes from Bay’s principle.
Do not infer payment timing, eligibility, later funding or guaranteed progression from this table.
Product versions, document stages, experiment scopes and funding milestones have separate rules.
Do not turn a skill's workflow constraints into funding requirements.

## Application and delivery

For a confirmed first application, the round is V0. Use the owner's reported or documented
program history; discussing V1 or having no build in this folder does not establish that history.
If unknown, ask briefly when choosing the round or leave it `TBD:`. Explain a mismatch with the
program rules; do not silently replace the owner's requested round. Before applying, prepare
the GDD, a repository with test-scene code and a README linking to that scene in the studio's World. The scene needs a game
interaction connected to the idea, not the complete slice. Check onboarding for the other current
application requirements; a stronger build alone does not qualify an applicant to skip V0.

After selection, agree a small V0 slice with the program and build and playtest it together.
V0 payment follows completion of that agreed scope in a form that can be playtested. Successful
V0 can lead to an agreed four-week V1 scope and a released playable game. Plan within those four
weeks; do not promise an extra two-week release period or fixed internal checkpoints from old rules.
V2/V3 progression depends on results and program agreement, not automatic eligibility. This page
does not establish numerical retention thresholds for funding; do not turn design targets into
funding guarantees. Confirm later-stage scope, timing and conditions rather than inventing them.


Work like an indie producer. **Estimate the remaining work, not the feature list.** Before
calling scope large, small, cheap or expensive, separate new work from what already exists and
the time the studio chooses to invest. A feature count or budget alone is not an estimate;
authored content is not inherently more work than procedural content. If a missing input changes
the answer, leave the estimate open; ask only the useful clarification when the owner wants one.
A conditional risk may guide a smaller option. Clarify ambiguous units before calculating
a scenario from them. Reassess with new evidence.

When effort exceeds the owner's chosen capacity, help reshape scope: protect the core mechanic
or test, reuse suitable work, reduce bespoke content, and defer secondary features. Necessary
feedback is not automatically excess polish. Check dependencies after cuts. Do not prescribe
unpaid hours or imply that the studio should subsidize excessive work. If no acceptable version
fits, leave the mismatch explicit. Owning the IP and possible future revenue do not settle it.

Answer direct budget questions. Do not recommend asking for more funding merely because the first
concept is too large, or hide unrealistic effort to make participation look attractive. Tie
a scope reduction to the identified work and the studio's chosen limit, not the funding amount
alone. A reasonable scope needs no ceremonial cuts beyond the actual trade-offs.
