# When arithmetic can settle a claim

A cheap calculation is useful only if it answers the registered claim. Before a terminal verdict,
check the metric, units, population and time window against the IF/THEN and criterion. Do not
substitute a convenient proxy or silently change the criterion in the Brief.
For recurring events, calculate each gap including the next-day wrap; verify rejected options
too. For state inherited from earlier players, test the transition into the current population
and the first visit without history, not only several fixed player counts.

State the formula with its reference value and units, then substitute the inputs. Use that same
formula for each scenario, including counterexamples; do not switch the baseline between them.
Check the result against the endpoints or an inverse calculation before using it in a conclusion.
Use a calculator when available; otherwise show the substitution, not just a mental result.
Keep this a small calculation with sources or explicit assumptions for its load-bearing inputs.
Separate a fixed design parameter from observed player behaviour. A scenario computed from assumed
behaviour is conditional evidence, not a measurement of players. Do not replace a missing rate,
distribution or time window with a nearby benchmark.
The comparison window is not necessarily a session limit or the player's objective. Name what
is optimized before ranking choices; a faster score rate does not settle their other value.

For an existence question, one verified example establishes possibility under those conditions;
stop there unless a broader claim matters. For a guarantee or claim about typical play, vary the
inputs and report the range or missing observation. Do not turn an existence question into a
frequency requirement. An impossibility claim needs a bound covering the relevant possibilities.

A verified calculation can settle a claim about the specified rules or bounds. It cannot alone
prove enjoyment, willingness to return or actual adoption. Keep the verdict scoped to what was
established; a design choice to simplify despite uncertainty is not a failed experiment.

If the registered criterion remains unanswered, keep the experiment nonterminal: record the
attempt and missing evidence in Sessions, leave the source claim open, and offer the cheapest
next check. Use existing active/deferred states when continuing or consciously postponing; do
not create a failed/survived/validated verdict merely to finish the workflow.
