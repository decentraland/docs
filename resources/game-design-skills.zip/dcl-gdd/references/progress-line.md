# The progress line — canon

Loaded by SKILL.md before the first showing (phase-0 handshake); hard-rule numbers refer to SKILL.md.

One line, never a table: kept current by the same write that lands each answer, re-derived from the
document at session entry and on resume (hard rule 4) — against the template's section list, quoted
here so the template is not re-read for it: §0 TL;DR · §1 Player Promise · §2 First Minutes & How to
Play · §3 Core Loop · §4 Why Players Come Back · §5 Social by Design · §6 Mobile-First · §7 World,
Look & Story · §8 Audience & Comparables · §9 4 Week Plan.

Use plain words: current section, what is written in the current pass, and the next useful step.
For example: *"Concept: loop and promise written; now world/feel; next, a one-page view."*
No graphical bar, percentage, implied contiguous section range or global completion score.
Written, approved and tested are different states; progress describes the document, not proven fun.
Use decisions.md to respect skips and postponed reviews. An open field is not automatically the
next task: name a step within the owner's current scope, or simply the stopping point.
Preserve [next-step ownership](hypothesis-log/files.md#shared-working-memory) when saving or resuming it.

Show it **at the handshake, at section close, and on request** (hard rule 4 writes at every
decision; the line shows at section close). It also lives in the document's status banner,
refreshed by the same write. Name the submission option when relevant, not every field still
missing from a full GDD. On a jump or Resume, use actual disk state and the owner's current goal.
Two reference points:

- **The submission bar** — the template's own bolded sentence: *nails Sections 1–3, has at least a
  little in Sections 4–5 (return and social play), and is honest everywhere else*. The moment it is
  covered, offer the fork — **go full** (name what remains) or **finalize for submission now**: the
  remaining fields become honest `TBD:`s (the plan where the question was put, `TBD: not discussed
  yet` where it never was — hard rule 1), then **the whole of phase 3**, not just its deletion walk.
  For submission, confirm Step K's requested round/contact only if needed; for a draft requested
  without more questions, leave unknown details `TBD:` rather than forcing a final question. Unchecked self-check boxes are the normal state of an honest submission,
  never a blocker.
- **The full document** — every section 0–9 written: the template's shape and the complete version; what *you* drive toward is the current stage's section set, which lands earlier. Both
  reference points are true at once — name the nearer one in plain words when the two differ. On re-entry, unresolved fields or
  working choices still select Resume (phase 0's field-level test).

Question counts stay stage-scoped and approximate (*"question 3 of ~7 for this pass"*), never a
global counter: stage 1 is ten to fifteen questions for an idea from scratch, six to eight when a
build has already answered most of them.
