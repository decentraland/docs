## Glossary — reading help, delete before submitting

| Term | Meaning |
|---|---|
| **greybox / blockout** | A rough version of your space built from plain grey shapes — playable, but without final art. |
| **vertical slice** | One small part of the game brought close to final quality, to show how the whole will feel. |
| **spawn** | The exact spot and view where a player appears when they enter your scene. |
| **World** | Your own Decentraland scene at its own address, separate from the main map. |
| **Genesis City** | The main shared Decentraland map, made of LAND parcels addressed by coordinates. |
| **NAME** | A Decentraland name you claim; it gives you a World address and the right to deploy there. |
| **IP** | Intellectual property: characters, names, logos, music, or designs that someone else owns. |
| **fps** | Frames per second — how smoothly the scene runs; higher is smoother. |
| **client** | The app used to play Decentraland — the desktop or mobile version. |
| **hook** | A mechanic that gives the player a concrete reason to come back — e.g. a daily goal or an appointment timer. |
| **pillar** | One of the 2–3 short phrases that define your experience — the things you never cut. |
| **scope** | Everything you commit to build; scope pressure is the temptation to build more than v1 needs. |
| **playtest** | Watching real players (playtesters) try your scene and noting what they do. |
| **fallback** | Your plan B if the first choice fails or is unavailable. |
| **power gap** | When long-time players are so far ahead that a new player cannot compete or contribute. |
| **retention** | How well your experience brings players back after their first visit. |
| **D1** | The share of new players who come back the next day. |
| **dashboard D7** | First-week return: the share of new players who come back at least once during days 1–7, as shown on the [program dashboard](https://decentraland.zone/creators-data/dashboard.html). |
