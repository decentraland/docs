# Exploring the core — moves, choices, repetition

Use when the author wants help finding the interesting part, or a core-loop claim needs a closer
look. Choose one useful move; these are optional coaching tools, not another interview stage.
Use the author's image first. Fictional examples below illustrate possibilities, not decisions to
insert into their game. Keep uncertainty under [parking.md](hypothesis-log/parking.md).

Here, a mechanic is a player action and its response; a loop connects actions back to a situation
worth playing again. We are exploring immediate play, not proving next-day retention.
For emotion, pacing or clarity, use [experience-prompts.md](experience-prompts.md); for preparation,
failure, retry or deeper interaction, use [challenge-experiments.md](challenge-experiments.md).
Read only the relevant guide, not both by default.

## Find the moment worth keeping

Ask for the moment the author most wants to experience. Follow what the player notices, tries,
and gets back. If the fantasy is clear but the action is not, offer to act out a short episode
using [the word run](interview-moves.md). Stop where the player needs to choose or react.

For a fictional lantern garden: do they enjoy arranging reflections, discovering what a reflection
reveals, or simply making the pond glow? Those could need different tests. Let the author choose
what matters before suggesting a rule. Do not require competition or mastery to justify quiet play.
A described episode checks whether the action makes sense; it is not evidence that it feels good.

## Get more play from an existing action

When the creator wants more depth, explore another use of an existing verb before proposing a new
system. What changes if the target, timing, position or intention changes? Reuse may still require
new engineering or content; it is not automatically cheap.

Fictional example: turning a lantern could reveal a path or shape a pattern. Try both situations
on paper and ask whether they invite different decisions. If they are the same instruction with
different decoration, the proposed depth is still unproven. Decoration may nevertheless be the
appeal in an expressive toy; do not treat that preference as a defect.

## Examine a choice that seems empty

When a loop promises strategic choice, ask when a player would prefer each option. A safer/riskier
pair is one possibility, not a requirement. Different expressive outcomes can also matter.
If one option appears always preferable, consider whether the alternative is hidden, harder to
execute, poorly explained, or genuinely inferior under the stated objective.

Trace two situations where the preferred action might change. For numeric payoffs, compare the
same units and include costs and assumptions; expected payoff alone does not describe timing,
uncertainty or player preference. A paper result exposes a rule problem, not actual player choice.

## Investigate the tenth repetition

Use an actual moment of boredom when one exists. What became predictable? What still feels
pleasant, permits expression, invites discovery or gives a reason to try differently? Separate
what the author hopes from what a player reported. Do not diagnose the cause from “too hard” or
“repetitive” alone.

Compare plausible explanations: exhausted decisions, unreadable outcomes, a long wait, awkward
control, or a mismatch with the intended mood or audience. Explore the smallest relevant change:
clearer feedback with the same choices, a different situation with the same controls, or a shorter
wait. Ask who supplies future variation and what that costs; neither procedural nor player-made
content guarantees an endless supply of interesting play. A repeatable pleasure is not proof of
return behaviour.

## Choose what to learn next

Offer the test that answers the uncertainty: words or tokens for choices and dependencies; a
small playable scene for timing, feel and voluntary repetition. For sensory questions, use
[feel-experiments.md](feel-experiments.md). Preserve enough of the intended experience to test the
claim; no complete art set or full GDD is required. The creator may build it themselves.

For a useful comparison, keep unrelated conditions similar, note practice/order effects, and
record both behaviour and the player's account. Reversing the order can help expose a practice
effect, but a small self-test remains limited. Reuse a relevant hypothesis rather than creating
one for every idea. An unresolved result can remain open without blocking the document.

## Intellectual background

This is an experimental, original coaching synthesis informed by wiki readings of Raph Koster,
*A Theory of Fun* (2010 reprint, chapters 3–5); Jesse Schell, *The Art of Game Design*, third edition
(pp. 179–182, 220–223); and Hunicke, LeBlanc and Zubek, *MDA* (2004, pp. 2–5). Their accounts guide
questions, not a universal diagnosis. The examples and proposed comparisons here are our own;
source locators come from draft wiki notes, not a fresh verification of those books.
