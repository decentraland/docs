# Horror tension — choices under pressure

Use one lens when a creator wants to examine an encounter, a quiet stretch or repeated play.
These questions and probes are our adaptations of contrasting accounts, not validated fear
methods. Follow the intended feeling; a brief, one-time experience needs no replay system.

## Before the encounter

When a scare arrives without a meaningful lead-up, ask what the player imagines might happen
and what they can do about it. Try the same encounter with a partial warning: a hanging lamp
moves before anything enters the room. Compare what players expected and chose, not just
whether they startled. Warning can support dread; announcing every beat can become tedious.
Neither surprise nor forewarning is always stronger. [1, 2]

## What can be trusted?

When mystery becomes confusion, separate knowledge of available actions from knowledge of the
threat. What can a player rely on, and what are they still trying to work out? Try keeping one
cue reliable while another remains uncertain. Showing a resource value can support decisions;
hiding a system can protect ambiguity. Neither approach calls for a compulsory meter. Ask what
players believed the cue meant before attributing hesitation to fear. [2, 3]

## Pressure, relief and time

When the experience feels flat, look at one transition: what changes when danger recedes, and
what makes the player leave that breathing space? Try changing the gap between two encounters,
keeping the encounters intact. A long walk may create isolation or simply waste time; ask what
occupied the player during it before cutting it. Repeatedly breaking apparent safety can also
change whether any later refuge feels safe. No fixed scare interval follows from these accounts.
A system's intensity estimate describes its inputs, not the player's emotion. [1, 4, 5]

## A way to respond

When a player can only wait or repeat one escape, ask which choice still matters: delay, hide,
distract, investigate, fight, or accept a cost? Try one response alongside the current one and
watch how it changes the encounter. Combat can support desperate survival or absorb attention
into mastery; removing it may create vulnerability or remove engagement. Treat both as design
options. For scarcity, try the encounter after an ordinary mistake has spent the key resource:
is there a recoverable decision, or has progress silently become impossible? [1, 6]

## A threat worth watching

When the antagonist becomes routine, ask what the player has learned and what remains uncertain.
What behaviour can they understand well enough to survive? What would make its next appearance
matter? Try a changed context or approach before adding abilities. Check any apparently safe
position: is it an intended tactic or a limitation that breaks the creature's fiction? Greater
randomness may prevent planning without making the monster feel alive. Distinguish failure to
notice a cue from failure to act on one. [2, 6]

## Loss and another attempt

When retries dominate, separate the loss players anticipate from the setback they actually pay.
Try a shorter recovery while keeping the threat's presentation; ask whether stakes or frustration
changed. Larger consequences remain an option when they serve the intended experience. On a
second pass, suspense might move from discovering an event to surviving it. Ask what remains
interesting after recognition; do not diagnose every learned sequence as failed horror or add
randomisation merely to promise replay. A better second run also includes practice. [3, 7]

## Company, humour and trust

When other people matter, identify their role: reassurance, rescue, shared panic, rivalry or an
unreliable ally. Try the intended group arrangement, including what each person can know or do.
Laughter may be relief or the desired social pleasure; it does not automatically invalidate
horror. If betrayal is possible, ask what participants understood beforehand, whether they can
avoid it, and what the betrayed player loses. Include that player's account when reviewing it.
Solo observations cannot establish the group experience; perpetrators' accounts cannot establish
victims' enjoyment. [1, 5, 8]

## Sources behind these lenses

Original coaching synthesis; no source passages, figures or game assets included.

1. Joshua Bycer, *Game Design Deep Dive: Horror* (2022), chs. 4–6, 9.
2. Bernard Perron, *The World of Scary Video Games* (2018), chs. 8, 10.
3. Tracy Fullerton, *Game Design Workshop*, 5th ed. (2024), including Erin Reynolds's interview.
4. Bernard Perron, *Silent Hill: The Terror Engine* (2012), ch. 4.
5. Mike Booth, *Replayable Cooperative Game Design: Left 4 Dead* and *The AI Systems of Left 4 Dead* (2009).
6. Thomas Grip, *9 Years, 9 Lessons on Horror* (2019); Philippe Morin, *Horror in the Making* (2015).
7. Tanya Krzywinska and Matthew Weise, essays in Bernard Perron (ed.), *Horror Video Games* (2009).
8. Marcus Carter and Staffan Björk, essays in Mortensen, Linderoth and Brown (eds.), *The Dark Side of Game Play* (2015).
