# Challenge experiments — choices, failure, depth

Load for a game whose author wants challenge or deeper decisions. Do not apply a challenge
checklist to a peaceful ritual or creative toy. Select a useful question and one possible test;
these are original coaching moves, not a completeness score.

## Before, during and after an attempt

Where could the player make a meaningful decision: preparation, execution or response to the
outcome? A route, tool or timing choice is an option, not a required loadout system. Trace how a
chosen preparation changes a later attempt. If it changes nothing relevant, ask whether it is
expressive customisation, unclear feedback or a decorative decision; those are different cases.

For a safer/riskier option, name what could be gained, lost or learned. Compare situations where
each might appeal; include time, effort, uncertainty and preference, not just expected points.
Fictional example: placing a lantern on a stable low shelf or balancing it higher could change
which shadow it reveals. The risk need not destroy progress. Ask whether that uncertainty belongs
in the author's desired mood before suggesting it.

## Let a failed attempt teach or entertain

What happened, what does the player understand, and what can they try next? Check the distance
from failure to another meaningful action, including waiting and repeated setup. Compare a quick
retry, a changed situation, or a playful response to the mistake. Preserve stakes the author
values; do not assume punishment or a minimum loss percentage is needed.

A fictional drifting seed might land in an amusing shape and remain available to nudge again.
That is an example to discuss, not a requirement for comic failure. Observe whether the response
invites another attempt or becomes repetitive noise. A short retry does not prove enjoyment.

## Check who can still participate

Trace a novice and an experienced player through the same situation. Can the novice understand
what might improve, and can the experienced player choose something interesting? If success
makes later success easier, examine whether the lead grows until alternatives stop mattering.
Try a cap, a different cost or a fresh round on paper only if that supports the intended game.
No particular catch-up system is mandatory, and equal outcomes are not the only kind of fairness.

## Grow relationships between actions

Try an existing action on a different target, combine it with another, or let it leave a trace
that changes the next attempt. What new choice follows? A changed order of actions can matter
without adding content; it can also create complexity and bugs. Count meaningful differences in
play, not verbs or combinations as a score of depth.

Watch for a player's useful strategy that was not planned. Check whether it expands expression
or removes everyone else's choices before calling it an exploit. For a numeric advantage, model
the same units, costs and distribution; test plausible edge cases rather than one lucky run.
The calculation predicts outcomes under assumptions, not the strategy players will actually use.

## Separate causal stories

When a proposed fix sounds certain, trace: the changed rule, the behaviour expected to follow,
and the experience it might create. Which connection is untested? Compare another explanation
such as unclear feedback or unfamiliar controls before adding difficulty. Use the cheapest test
that distinguishes them. The result may support only one connection, not the whole promise.

## Background

Original synthesis informed by Koster, *A Theory of Fun* (2010 reprint, chapter 7); Schell,
*The Art of Game Design*, third edition (pp.179–182, 220–223, 298–305); Swink, *Game Feel* (2009,
p.305); and *MDA* (2004, pp.3–5), via the wiki. Challenge anatomy, risk/reward and causal layers
are lenses with limited scope. The fictional example and test suggestions are ours; no author's
full checklist or fixed loss rule is reproduced.
