# The GDD Section Map

The interview order, which is **not** the document order. Sections are ordered by dependency: each
answer constrains the ones below it. Apply hard rule 4's write-before-reply sequence after
each answer that changes content, including a partial seed. Keep template order on disk while asking in this order.
A plausible detail needed to fill a cell is still a new decision: hard rule 1 applies.
The template supplies **all fields, table cells and caps** — the step's own
block is `assets/gdd-template/s<N>.md`; this map supplies sequencing, dependencies and
section-specific moves — it is not a second field checklist.

Section numbers follow the template: §0 TL;DR · §1 Player Promise · §2 First Minutes & How to Play ·
§3 Core Loop · §4 Why Players Come Back · §5 Social by Design · §6 Mobile-First · §7 World, Look &
Story · §8 Audience & Comparables · §9 4 Week Plan.

Per step: **Ask** = what to put to the owner. **Good** = a resolved answer. **Smell** = an answer
that sounds resolved but is not. **Load** = the knowledge reference to read when this step begins.
**Park** = what in this section is *always* a claim rather than a decision, and therefore belongs in
the Hypothesis Log ([parking.md](hypothesis-log/parking.md)).

**Load is per step:** the section's knowledge reference, named in the step's file — shapes, smells,
probes, deck excerpts and the provenance of every number (hard rule 5). [playbook.md](playbook.md)
(standing rules, platform fit, success criteria, voice) is read once, at the first step. A reference
is read once per session: a later Load line naming a file already in context is a pointer, not a
re-read.

Cluster related table rows into one decision per hard rule 2 (Step G shows the §5 clusters).
After roughly 2–5 exchanges, notice whether the exploration is productive; this is not a limit.
If it stalls, offer once: keep exploring, or hear a concrete proposal from you? Follow their
choice. Do not interrupt fruitful brainstorming to meet a count or force a yes/no decision.

**On the Harvest route (1E):** fill every step from the repo first — scene code, experiment files,
`ideas.md`, `decisions.md` — and interview only the holes. The map's order still applies to the
holes; the steps filled from the repo are announced, not asked. Reading the code needs no
procedure, but it has a hard edge: a repo shows **what was built**, never why, never whether it is
fun, never who it is for. Readable: the verbs, the loop steps, cycle length, player counts, what
already runs on mobile. Not readable: the promise, the pillars, the audience, the return hooks, and
every *why* — infer one of those and it is `[agent-decided]` until the owner says otherwise. Say in
one line which fields came from the repo.

---

**Concept first:** on a new idea, connect the seed, a typical solo moment, the loop and its
world before initiating detailed Retention or Social. Reuse what the owner already supplied;
ask only what prevents them from picturing the experience. Once it is showable, offer the
[early HTML](stages-and-gates.md#the-html-render), even with open questions. A prototype may
start sooner; neither the page nor the full stage set is a prerequisite. Existing documents,
Resume and owner jumps use their actual gaps, not a restart of this route.

### Optional core-lens exploration

Once the mechanic or intended loop is imaginable but still easy to change, offer one creative
look through game-design lenses before initiating detailed Retention/Social. Do not wait for
measurements or the experimental gate. For example: *"The loop is taking shape. Want to explore
what feels good in the action, what could keep repetition ten interesting, or how the player
reads what is happening? We might find a new angle or something small to try."* Adapt to this game.

On acceptance, use SKILL.md's **Current question** table to read the relevant playbook blocks
(unless already loaded), then select two or three useful lenses. Start with one: connect it to
a concrete game moment through a question, imagined episode or small experiment. Follow the
owner's response rather than presenting a lecture or completing a fixed list. Do not load all
five files by default. Lenses are compatible views, not mutually exclusive game directions:
movement, composition and familiar repetition can coexist. Ask for a trade-off only when this
game has a concrete conflict. Keep alternative explanations and uncertainty; a suggestion is not an
owner decision and a word run is not a playtest.

This is an optional interview move, also in doc-only; build invitations still follow that mode.
If an equivalent exploration already happened naturally, do not repeat the offer. Record the
offer/answer briefly in decisions.md so Resume does not repeat it. Declining or skipping delays
nothing. Do not stack it with the HTML offer or pilot review; respect a request to stop.
Pilot review checks the record; this move explores the game. Acceptance here is not required
for ordinary question-driven reference loading or the agent's own factual checks.

**The steps live one per file** in [section-map/](section-map/), `a.md`–`k.md`, in the order
below — load a step's file the moment the step begins (with its Load), never the whole set up
front. Steps out of the current stage's scope are never
loaded at all.

- **Step A — The seed (feeds §1):** [section-map/a.md](section-map/a.md)
- **Step B — §3 Core Loop:** [section-map/b.md](section-map/b.md)
- **Step C — §1 Player Promise:** [section-map/c.md](section-map/c.md)
- **Step D — Comparables (closes §8's comparables table):** [section-map/d.md](section-map/d.md)
- **Step E — §2 First Minutes & How to Play, written as "you":** [section-map/e.md](section-map/e.md)
- **Step I, world part — §7 World, Look & Story:** [section-map/i.md](section-map/i.md).
  Bring forward the mood/response already discussed in B; close only the missing world details.
  This completes the usual concept set.
- **Step F — §4 Why Players Come Back:** [section-map/f.md](section-map/f.md)
- **Step G — §5 Social by Design:** [section-map/g.md](section-map/g.md)
- **Step H — §6 Mobile-First:** [section-map/h.md](section-map/h.md)
- **Step I, audience part — closing §8 (stage 2):** [section-map/i.md](section-map/i.md)
- **Step J — §9 4 Week Plan (v1 scope):** [section-map/j.md](section-map/j.md)
- **Step K — §0 TL;DR, and the header table:** [section-map/k.md](section-map/k.md)
