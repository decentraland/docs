# Player Promise — make the game imaginable

Loaded at Step C (§1). The seed at Step A aims it; the optional familiar comparison closes at Step D.

**Job:** in at most 25 words, convey a role or situation, main action, goal and meaningful tension
or distinction. The sentence shape is free. Start with the owner's imagery and intent, not a
ready-made concept. If their line already works, keep it.

## Help the owner find the line

Ask what a player would actually do and what makes that moment worth imagining. If an unfamiliar
idea is hard to picture, try a familiar activity or genre as an anchor. A named game can help too,
but explain this game's difference rather than promising a better version of someone else's.
Check that any comparison implies the right activity: a marketplace suggests trading, not just
browsing objects. If the promise is clear without a comparison, omit the optional anchor.

When useful, offer one or two short drafts using only agreed material. The fictional lines below
illustrate ways to frame a promise; they are examples written for this reference, not real pitches,
quotes, tested hooks or concepts the owner must adopt:

| Emphasis | Fictional example | Question it helps answer |
|---|---|---|
| Activity and an unusual condition | You guide a ferry through fog, finding passengers by the bells they ring. | What makes a familiar action different here? |
| A rule the player can picture | Each bridge you cross folds behind you; deliver the lantern before you run out of paths. | Can one consequence explain the challenge? |
| A familiar activity outside games | A lost-and-found desk for migrating clouds: match each drifting shape to the weather its owner remembers. | Would an everyday situation make the fantasy clearer? |
| A preferred way to play | A climbing puzzle for patient explorers: find a route by watching shadows move across the wall. | What kind of attention does this invite? |
| Mood expressed through action | Tend a tiny observatory where shy constellations appear when you dim the lamps. | What does the player do to experience that mood? |

These are flexible examples, not an exhaustive taxonomy. Translate the useful approach into the
owner's idea; do not copy its setting or mechanics into their GDD. Real-game examples remain useful
on request: verify the specific point, link its source, and explain it in your own words instead
of reproducing a pitch or store description.

## Try it with a listener

Could someone unfamiliar with the project describe the action after hearing the line? Ask what
they pictured and what interested or confused them. A friendly reaction is not evidence of demand.
If they imagine the wrong game, clarify the action or the comparison; if they understand it but
are not interested, explore the intended audience or appeal rather than adding adjectives.

## The optional "Why this game" block

Keep a personal reason when it explains a design choice. For example, experience tending a shared
garden might explain why this owner cares about leaving visible help for the next visitor.
That is a fictional illustration, not a backstory to assign. Ask for their reason; if the answer
would fit any team or game, the block can be omitted. It is creative intent, not a CV or a sales
forecast.

## Probes and smells

- "Which moment would you want a friend to imagine?"
- "What does the comparison make people expect that your game will not do?"
- Watch for vague praise, several unrelated twists, or a promise made entirely of other titles.

## Park

A prediction about player interest or word of mouth is a hypothesis, not a fact established by
writing a good line. Keep its intended surface clear: promise, trailer or spoken explanation.
One agreed promise enters the document; offer to park useful alternatives in `design/ideas.md`
([interview-moves.md](interview-moves.md)).

## Background

Earlier coaching drew on Chris Zukowski's [anchor discussion](https://howtomarketagame.com/2019/12/23/know-your-games-anchor/),
[Rebekah Saltsman's pitching interview](https://www.gamedeveloper.com/business/pitching-your-game-with-rebekah-saltsman)
and public pitch examples. These are background references, not endorsement or evidence that the
fictional examples above succeed. The project's provenance record tracks the removed excerpts.
