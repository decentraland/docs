# Section Map — Step I — §7 World, Look & Story, and closing §8

A step of [../section-map.md](../section-map.md) — its preamble applies here.

## Stage 1 — World, Look & Story (§7)

Complete this part after E, before F on the default route; reuse the solo moment from B.
Do not ask again for settled mood, sound or world details. Return for the audience part at stage 2. An owner-requested jump
still takes precedence (hard rule 8).

- **Ask:** the world in **2 sentences** — really two; only premise and context that change what the
  player does. Then the visual direction: how avatars, interactables, objectives and navigation stay
  readable on a small screen, and one screenshot-level visual signature that is unmistakably theirs.
  Do not ask for an image or a reference list (the template dropped both); mention once that a
  screenshot strengthens §0.
- **Hand them a generation prompt.** When the signature settles or two candidates tie, offer a
  ready-to-paste image prompt per candidate (composition, palette, mood, lighting, aspect ratio; no
  text or logos), **anchored to Decentraland's avatars and art direction** so it stays buildable —
  with a line asking the generator to look up Decentraland's current in-world visuals if it can
  browse. A greybox screenshot still outweighs generated art in a submission; generated images
  choose the signature or stand in as placeholders.
- **Sound, optionally:** ask what the player hears and what survives on a muted phone.
- **Good:** Story that changes what the player does; a signature recognisable in one screenshot.
  Lore walls and polished concept art in place of a space plan are smells. If the story cannot
  fit two sentences, it is not load-bearing.

**Visual coaching:** could the owner point to what makes this view theirs without its title?
Show an ordinary playable moment and the mood they intend, not a staged exception presented as
normal play. For example, compare the same space before and after a chosen player action; label
mockups as intended states, not screenshots of an existing build. Let the wording carry their tone.

## Stage 2 — Close Audience (§8)

On a stage-1 interview, stop above; do not ask these fields yet.

- **Ask:** the primary player + arrival context in one sentence (the template's shape:
  *for players who already enjoy ___, arriving alone / with friends / from an Event or Community,
  looking for ___* — or describe their preferred mood and pace); how the first group plausibly arrives (max 2 sentences — Discover, an Event, a
  Community, friend invites, an external link) and why enough people overlap to reach §5's social
  threshold; and the **deliberately-not-for** line. The comparables table closed back at Step D —
  check it still matches the game the interview has produced since, and say so if it does not.
- **Good:** A first-group answer names a channel, not "organic growth"; the primary player is
  specific, not "everyone".
