# Experience prompts — emotion, rhythm, discovery

Load when the creator wants help expressing the intended pleasure, or observation does not match
the pitch. Choose a relevant prompt, not a survey. These are possibilities, not required types of
fun. Follow the author's words before introducing a theory.

## Give the intended pleasure a concrete home

Ask which moment should make someone curious, proud, calm, amused, absorbed, or pleased with what
they made. Let the author add another description. What action or response could carry it?
Fictional example: a dusk garden might reward arranging a shadow, finding an unexpected silhouette,
or watching a familiar pattern settle. None requires an audience or a harder challenge.

If the author asks for inspiration, offer contrasting small scenes, not a verdict about which is
best. Keep the selected image; proposed mechanics still need visible agreement. The same action
can support several experiences without needing to cover every category.

## Observe rather than assign an emotion

Watch where a player pauses, experiments, repeats, changes approach or stops. Ask what was going
on for them at that moment. Silence can be concentration, comfort or disengagement; a cheer may
suggest triumph but does not prove it. Compare their account with what happened, including a
reaction unlike the intended one. A quiet player is not automatically an unsuccessful test.
For pride, ask what felt like their contribution. Offer assistance openly; do not hide it merely
to manufacture an impression of achievement. Another player may amplify a moment, but test solo
appeal on its own. Enjoyment, intention to return and actual return are different observations.

## Explore rhythm without prescribing escalation

Sketch a short visit as moments: invitation, attempt, response, space to notice, another attempt
or a satisfying stop. Where would anticipation, relief or discovery fit this game? Not every
visit needs a dramatic peak. Compare a version with a little breathing room after an outcome
against one that immediately demands more. Observe whether the pause helps appreciation or feels
like waiting. A drawn interest curve records intention, not measured player interest.

## Make the next action discoverable

When a player is lost, distinguish an invisible opportunity from too many competing cues. Try
emphasising the relevant object, or removing nearby noise, before adding instructions everywhere.
A clue can invite discovery without disclosing the answer. In a fictional sound garden, a faint
reply from one stone could invite a tap; a permanent arrow could spoil the intended listening.
Compare what players notice and infer, not just how fast they finish.

Reveal an additional control or possibility when it becomes useful or the player seeks it.
Fewer starting options can help, but do not impose an option count or force experienced players
through a tutorial. Let creation itself be the first satisfying moment when that is the appeal;
a compulsory shortcut could remove the reason they came. A prompt to invite friends should not
interrupt the experience the creator is trying to establish.

## Read motivation without grading it

If a reward seems to be doing all the work, ask what the player looks forward to doing and what
the reward changes. Could it support an interesting choice, or does it merely prolong an unwanted
action? Consider competence, curiosity, expression, ownership, company or meaning as questions,
not proven causes or a quota. A classification alone establishes neither benefit nor harm.

For a proposed incentive, trace the behaviour it rewards, including an unintended shortcut. Does
that behaviour serve the intended experience? More actions or longer sessions could mean confusion
or obligation. Ask whether players understand the mechanism and can stop when they wish. Use this
when relevant; do not add a mandatory motivation matrix, score or business dashboard to the GDD.

## Background

Original prompts informed by wiki readings of Lazzaro, *Four Keys* (2004, pp.2–7); Hunicke,
LeBlanc and Zubek, *MDA* (2004, pp.2–5); Schell, *The Art of Game Design*, third edition (pp.133–137,
298–309, 347–351); and Chou, *Actionable Gamification* (chapters 6, 10, 13–17).
Their vocabularies ask different questions. Observational work and practitioner advice are not
universal recipes. Fictional examples and suggested comparisons above are our own.
