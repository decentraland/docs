# Section Map — Step A — The owner's seed (feeds §1)

A step of [../section-map.md](../section-map.md) — its preamble applies here.

Start from what the owner already brought: an idea, prototype, notes, a remembered game, image,
mood or activity. Read it first. Do not open with a menu of your own game concepts just because
the input is short. If the seed is missing, ask one open invitation to share what they already
have in mind, including any inspiration. A rough fragment is enough; no pitch or genre is required.

If they name a reference, find the particular action, feeling or quality they want from it when
that is not clear. Do not import the reference's entire design or assume they played it. Reuse
what they already told you; the later Comparables step adds analysis, not another request for the
same inspiration. This early orientation needs no full reference research or comparison table.

Save the owner's supplied seed as a partial §1 before the next question; it need not be a finished
promise. Reflect it briefly in conversation without committing your own interpretation as their
design. The 25-word cap waits until Step C. A rich or messy answer is design
material to organize with the owner, not a failure to supply one line. Before narrowing to fields,
let them unfold what matters to them — their fantasy, inspiration and loose ideas, across as many
messages as they need. If more is coming, acknowledge briefly and wait instead of starting questions.
When a useful shared picture emerges, invite the transition: "Anything else you want to add, or
shall we explore how this plays?" Follow their answer; an explicit request to move on already counts.
Do not ask after every fragment, repeat the whole summary or require a complete inventory. A prior
agreement to the overall route does not mean they have finished sharing. They can add ideas later.

- If the owner has no seed and wants help finding one, offer a small set of distinct starting
  points as proposals they can reject or combine. Do not choose their creative direction for them
  or require a separate ideation skill. An explicit brainstorming request needs no permission loop.
- If a real pitch already exists, preserve it as §1; after the owner is ready, go to the first
  genuine gap. No restart.
- If several ideas arrive, help choose a focus and park the others; do not discard them merely
  to make the opening fit a form.
- Detailed comparison of two played games remains Step D. A reference can inspire the concept
  without automatically qualifying as a first-hand Comparable.
