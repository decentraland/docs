# Scene resources — find a useful starting point

Read when a prototype needs models, materials, textures or sound. First consider
the project's existing assets and the installed SDK asset catalog. Search for the missing piece,
not a whole new visual direction. One compatible set can save more time than many unrelated finds.

## Places to look

| Need | Source | Selection hint |
|---|---|---|
| Simple environment kits and props | [Kenney](https://kenney.nl/assets) | Browse 3D sets for a consistent style; inspect the selected pack's formats and license. |
| Modular buildings, nature, props or characters | [Quaternius](https://quaternius.com/) | Check the specific pack, included files and download tier; a rig or animation is not automatically compatible with a DCL avatar. |
| Surface materials and realistic models | [Poly Haven](https://polyhaven.com/) | Choose only the resolution and detail needed for this scene; [asset license](https://polyhaven.com/license). |
| Surface textures and materials | [ambientCG](https://ambientcg.com/) | Inspect the maps needed by the chosen SDK material rather than importing every map; [license](https://docs.ambientcg.com/license/). |
| Grid textures to judge scale | [Kenney Prototype Textures](https://kenney.nl/assets/prototype-textures) | This pack lists CC0. A grid helps compare dimensions only when its mapping has a known scale. |
| Consistent prototype shapes and props | [KayKit Prototype Bits](https://kaylousberg.itch.io/prototype-bits) | Free pack lists CC0 and glTF; extra/source tiers differ. Try one import before using the set throughout. |
| Short synthetic sound feedback | [ChipTone](https://sfbgames.itch.io/chiptone) | Browser sound generator; the author lists generated sounds as CC0. Useful for stylized feedback, not a substitute for recorded ambience. |
| A specific recorded sound | [Freesound](https://freesound.org/help/faq/) | Downloads need an account; license and attribution vary per sound. Verify the selected upload's provenance and SDK format support. |

These are discovery links, not pre-approved downloads or verified DCL imports. Use the installed
SDK asset workflow for selection, conversion and import. Inspect scale, pivot, materials, collision
and animation where relevant in a small scene before repeating the asset across a level.

Keep the chosen asset's page, author, license and required credit alongside the project's asset
record; use the existing [reference notes](../../dcl-gdd/references/hypothesis-log/files.md#reference-notes)
for inspiration. A free download does not establish all reuse rights. If the exact asset has
unclear terms or needs too much repair, suggest another source or a placeholder. Do not turn
asset hunting into a prerequisite for trying the mechanic.

## Further browsing

[The Level Design Book — Assets & Resources](https://book.leveldesignbook.com/appendix/resources)
informed the initial shortlist and offers more catalogs; the additional audio and KayKit links
come from their providers. Its engine-specific packages and
skyboxes are not promises of DCL support. Links checked 2026-10-06; recheck the selected item
when using it. No asset files are bundled here.
