# Section Map — Step E — §2 First Minutes & How to Play, written as "you"

A step of [../section-map.md](../section-map.md) — its preamble applies here.

- **Ask:** Second person, present tense, along the template's time table: 0–5 seconds (what do you
  SEE at spawn that tells you what to do, with nothing to read), 5–10 seconds (what happens when you
  act — by 10 seconds the player can state the immediate goal), 10–60 seconds (first complete
  micro-goal, shortest necessary hint, first reward, first optional social signal), 1–3 minutes
  (first complete loop or a smaller cycle with a meaningful payoff), 3–10 minutes (first meaningful
  choice or escalation, next visible goal), and the natural stopping point — the last thing you see
  before leaving can show the next wanted action. Once §4 exists, connect its chosen return
  hook here; at concept stage do not invent Retention systems to fill this stopping point.
  Write the known first-minute action and payoff now; only its missing next-visit link waits
  for Retention, not the whole episode.
- **Then:** the player-facing **How to Play** — exactly 3 bullets, maximum 8 words each: the main
  verb + immediate objective, how progress works, how another player changes the experience.
- **Voice:** use the author's concrete imagery and game verbs in How to Play. These are readable
  player instructions, not system specifications or marketing claims. Keep the three short bullets
  actionable; flavour must not hide what to do or invent new fiction. Translate meaning naturally,
  rather than copying awkward phrasing, and do not require another sign-off for a pure rewording.
- **Good:** A reader can picture and follow the intended scene. The spawn frame communicates the verb.
  Vivid present tense describes the intended experience; it is not a claim that anyone tested it.
- **Smell:** UI narration ("you click the button"), a tutorial, an NPC, a sign with instructions,
  lore, or the first minutes spent walking and reading.
- **Cap:** 180 words across the Player experience cells (exclude fixed time labels);
  How to Play has its separate 3×8-word cap.
- **Load:** [core-loop-and-ftue.md](../core-loop-and-ftue.md)
- **Park:** the template's **5/10 rule** — 80% of playtesters perform the first useful action within
  5 seconds and can state the immediate goal within 10 — is a program bar *and* a hypothesis; park
  it; it is testable with three people and a greybox. Untested is fine at this stage, and the
  template says so.
