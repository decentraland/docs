# Section Map — Step G — §5 Social by Design

A step of [../section-map.md](../section-map.md) — its preamble applies here.

- **Ask:** the template's table, hardest rows first. The repeatable social loop (A signals → B
  responds voluntarily → shared consequence → reason to regroup — the response must change another
  player's options, outcome, reward, status, relationship, or moment-to-moment play). The
  **disappearance test**: if every other player vanished but their traces remained, what exactly
  breaks? — *"nothing breaks"* is an honest answer if said openly: it describes solo play with social
  evidence around it. From strangers to a group in 30 seconds, without voice or shared language. Recognition
  & continuity: where does a player first learn another player's name, and what persists between
  returning players. **Quiet hours & player counts**: what a solo player can do, the social
  threshold, the ideal group, the target player count — and how a solo arrival meets another player
  **by design, not luck**. Drop-in / drop-out: a late arrival contributes immediately; a leaver or
  spoiler does not break play. Then one sentence each: the bystander test, the memorable moment, and
  bring-a-friend (max 2 sentences).

**Five messages for nine rows** — the rows group, and the map's 2–5 rule counts clusters:

| Decision | Rows resolved together |
|---|---|
| **Is it social at all** | the repeatable loop plus the disappearance test |
| **Meeting and recognition** | strangers to a group in 30 seconds · where a name is first learned · what persists between returning players |
| **Population** | quiet hours · the social threshold · the ideal group · the target player count — four numbers, one decision |
| **Robustness** | drop-in / drop-out — load-bearing, so it gets a message of its own; in a list the colour rows would answer for it |
| **Colour** | the bystander test · the memorable moment · bring-a-friend |

- Check [worthwhile solo play](../social-design.md#solo-means-worthwhile-not-merely-possible) before
  treating quiet hours as resolved; reuse the core-loop answer, do not interview it again.
- **Good:** Group-scaled rewards, multiplayer-only moments, an audience, async traces, 2-second
  social verbs a stranger can use on you. A satisfying lone-arrival experience that another player improves.
  Real numbers in the player-counts row — §6 performance and §8 audience both depend on them.
- **Smell:** "There's chat." "They can team up if they want." Parallel solo play in one room. A design
  that assumes a full world.
- **Rows are lenses, not requirements.** A row that is not how this game works gets one honest line
  or is **deleted** — offer the deletion yourself (the rule: SKILL.md, **The growing document**). Two
  exceptions: the **disappearance test** is never dropped (*"nothing"* is a legal, informative
  answer), and **quiet hours & player counts** goes only out loud, its dependents' `TBD:`s in the
  same write (SKILL.md: dependencies travel in the same write).
- **Load:** [social-design.md](../social-design.md) · [design-lenses.md](../design-lenses.md) for questions
  about agency, company and feel, including alternative explanations and empty-scene tests.
- **Loop back:** if Step F picked a crew or team hook, this section has to make it real — and if this
  section produced a strong social obligation, go back and check it is claimed in 4.3.

- **Before moving on:** apply the [HTML update rules](../stages-and-gates.md#the-html-render)
  at this section close, including in doc-only. An existing core page is not a reason to skip it.
