## Before you start — delete this whole section before submitting

- **Check the filled example first (`gdd-example.md`): that is what a finished GDD looks like** — including its length and its honest `TBD:`.
- Can't answer a question yet? Write `TBD:` — no question blocks submission. `TBD:` is a legal answer in any field. **If a field is simply not how your game works, delete it instead.**
- **Respect the provided word limits for answers.** Short writing forces clear thinking; we can always ask for more detail later.
- **A rough sketch or greybox screenshot beats polished concept art.** We fund games, not documents.
- **Anything playable is a bonus** — put the strongest link in the TL;DR.
- Write simple, direct English (B2 level). Unfamiliar platform word? See the **Glossary** at the end.
- For submission, delete this section and **everything written in italics** — guidance, word limits, program notes — plus the Glossary and unused placeholders; keep headings, field labels, tables, and your answers.

**A GDD that nails Sections 1–3, has at least a little in Sections 4–5 (return and social play), and is honest everywhere else is a legitimate first submission.**

---

*What we fund: **social-first, replayable, high-retention, mobile-ready experiences with clear progression.***

