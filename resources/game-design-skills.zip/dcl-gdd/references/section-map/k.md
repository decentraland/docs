# Section Map — Step K — §0 TL;DR, and the header table

A step of [../section-map.md](../section-map.md) — its preamble applies here.

Filled last, read first.

- **Ask:** almost nothing new. Compose it from what is already decided: the one-line promise copied
  from §1, the primary player copied from §8, the current status (idea / sketches / greybox /
  core-mechanic prototype / playable core loop / vertical slice), and one sentence on what is live at
  the end of the round.
- **Confirm the requested funding milestone:** first application → V0; an existing participant
  uses the milestone agreed with the program. Unknown history stays unknown: neither a missing
  build here nor this being a new conversation means a first application. Do not infer V1
  eligibility from a playable loop or the game's version number. Use
  [funding and scope](../funding-and-scope.md); `TBD:` is legal when the agreement is unknown.
- **Non-negotiable:** if anything playable exists, its **link goes here**. Playable evidence
  outweighs pages of description, weighed in this order: core-mechanic prototype (*good*) → playable
  core loop in SDK7 (*great*) → vertical slice live in a World (*excellent*).
- **The evidence rule applies** ([scope-and-evidence.md](../scope-and-evidence.md)): a reported past test
  keeps its attribution and limits; no accessible build means no invented playable link. Park the
  remaining uncertainty and offer a relevant test, without erasing the earlier observation.
- **Fill the header table too:** experience title with the IP & Content Policy status (owner declaration / name screening / unresolved concerns — use the [IP self-check](../scope-and-evidence.md#ip-and-content-declaration--now-a-header-self-check)), the deployment target (World
  NAME, Genesis City coordinates, or `TBD:`), studio, date, and contact in the template's own form — **Discord plus email**, not one or the other.
- **The one-last-question block** at the template's end is optional feedback to the program — offer
  it once ("which section was hardest?"), never press.
