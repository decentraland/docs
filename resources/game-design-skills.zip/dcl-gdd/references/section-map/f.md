# Section Map — Step F — §4 Why Players Come Back

A step of [../section-map.md](../section-map.md) — its preamble applies here.

It matters in review. Seek a concrete reason to return; a clear existing answer needs no extra
rounds simply because the section carries weight.

**Ask, in this order** — the template fills 4.1 *after* 4.3, so interview hooks first:

1. **4.3 — two hooks.** Exactly **two** return hooks, chosen from the template's menu or invented,
   each with its exact trigger or timing, what the player anticipates, and the reminder channel plus
   the no-reminder fallback — at least one must create a concrete next-day (D1) reason.
2. **4.1 — the D1 sentence.** *"A player who enjoyed their first session returns the next day
   because [Hook 1 or 2] ___, which they know or anticipate from ___"*. Name a time only if
   the hook depends on it; establish what the player knows before re-entry.
3. **4.2 — the progression chain.** End of first session / end of first week / week 3+, each row
   naming what persists, what becomes possible next, and **how another player can tell**.
4. **The first-week scene.** 3–4 sentences in second person; if it reads the same as the first
   session, the section has work left.
5. **Economy, if present.** The one-line earn/spend/abuse answer for currency or tradable rewards.

- **Good:** A wanted next discovery, a new approach to a known challenge, or a chosen timed
  opportunity — concrete in this game. A first-week state that is visible to strangers.
- **Smell:** "Because it's fun." "More content." Hooks name-dropped from the menu with no mechanics
  behind them. The week-3+ row empty or "a bigger number". An invisible XP number.
- **Load:** [retention.md](../retention.md) — read it before asking anything here, not after. The theory
  under its rules, when a hook needs to be invented rather than picked, is in
  [design-lenses.md](../design-lenses.md): questions about chosen activity, pressure and a reason to return,
  with alternatives and tests rather than guaranteed psychological effects.
- If the owner supplies a test observation, keep it as attributed evidence next to the section
  or link its record ([evidence placement](../scope-and-evidence.md#why-playable-evidence-outranks-everything-written)).
  The anticipation cell says what the player expects, not how many testers returned.
- **Park:** every hook makes a claim about behaviour, not a proven result. Create separate cards
  only when [parking requirements](../hypothesis-log/parking.md) are met; otherwise preserve the
  intended hook and open test in the section without demanding a criterion now.

- **Before moving on:** apply the [HTML update rules](../stages-and-gates.md#the-html-render)
  at this section close, including in doc-only. An existing core page is not a reason to skip it.
