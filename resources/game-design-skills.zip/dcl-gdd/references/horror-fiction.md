# Horror — fiction, feeling and audience

Use for story, tone or character questions. Pick one helpful lens, not a questionnaire.
Keep comedy, action and one-time stories open.

## A reason to enter

What matters to this player before the threat arrives: a promise, a person, a discovery, a task?
What can they do about it? If the story lives in optional clues, try the opening with one clue
missed. Ask what the player thinks they are doing and why. This checks the route through the story,
not whether every piece of lore was collected. A cut-scene is an option. For a film reference, ask what becomes an action or choice rather than copying its scene.

## The invitation and the turn

When a scene changes tone, compare what its title, first room and first action invite with what
comes next. Which familiar convention helps; which variation unsettles?
Try the transition with someone who has not heard the reveal. Ask what they expected before and
after it. A quiet start can invite attention or feel empty; a sudden loss of control can surprise
or feel broken. A horror section can change a familiar action without abandoning everything learned.

## Who the actions say you are

Does the character's behaviour in play match the role the fiction gives them? A mismatch can be
intentional: a confident guide who cannot face one particular room. Try that encounter and ask how
the player understood the hesitation. Did it reveal something, or seem like an input failure?
A story explanation can make a restriction meaningful, but does not excuse unusable controls.
When someone says immersion broke, ask whether they mean attention, control, world logic or caring
about the story; those suggest different changes. Avoid treating maximum realism as the only goal.

## More than being scared

Is the player worried for someone, afraid of their own next move, amused, moved, or impressed by
how an effect was made? These can coexist. Try a small quiet aftermath or an unexpected kindness
beside the threatening moment, if that fits the author's image. Ask what stayed with the player.
Admiring the craft need not cancel involvement; laughter need not mean failure. Neither proves
that the intended fear happened. Compare accounts with actions, not assumed emotions.

## Looking and approaching

What does inspecting the threat give, expose or cost? Could the player feel watched even while
searching for useful information? Try an encounter with a reason to look and a reason to move on.
Ask what they were watching for. If contact is meant to repel, try changing one sound or surface
cue and ask what being near it suggested. Disgust, danger and sympathy may differ: a creature can
be frightening and seem in need of help. Gore is optional; an avoidance response alone cannot tell
which feeling caused it. Check camera and interaction feasibility through platform-fit.

## Whose experience is assumed

When themes or roles matter, ask who gets to act, who needs rescuing, who is treated as a threat,
and whether the ending changes that distribution. What does the player actually do to others?
Does a cultural reference require knowledge this audience may not share? Ask players with different familiarity how they read the same moment. Do not turn one reading into a
claim about a whole culture or gender. If illness is used to explain danger, examine what the work
suggests about real people, not just whether the twist works.

A label such as horror, parody or folklore cannot guarantee a shared interpretation. Make the
intended tone understandable and provide a way out when a scene asks for disturbing participation.
A critical or uncomfortable response can be relevant evidence without becoming an automatic
instruction to remove the theme.

## Reading behind these lenses

Original coaching synthesis, not a reproduction of the books' examples or frameworks:
Bernard Perron, *Silent Hill: The Terror Engine* (2012), and *The World of Scary Video Games* (2018);
Andrei Nae, *Immersion, Narrative, and Gender Crisis in Survival Horror Video Games* (2022);
Kirkland, Ekman & Lankoski, and other contributors in Perron (ed.), *Horror Video Games* (2009);
Chapman & Linderoth and Brown in Mortensen, Linderoth & Brown (eds.), *The Dark Side of Game Play*
(2015); Joshua Bycer, *Game Design Deep Dive: Horror* (2022). These mostly interpret games, rather
than establishing measured effects across players. Tan's emotion distinction is encountered through
Perron; Hawreliak's agreement between modes through Nae; Goffman's framing through the anthology.
